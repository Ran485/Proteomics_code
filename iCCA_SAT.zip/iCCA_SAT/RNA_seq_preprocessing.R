library(limma)
library(Glimma)
library(edgeR)
library(dplyr)
library(Homo.sapiens)
library(GenomicFeatures)
library(ComplexHeatmap)


## Reading in count-data
RNA_count = read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/raw_DATA/iCCA_merged_counts_sorted_filter5_thresh30.csv")
rownames(RNA_count) = RNA_count[,1]
counts = RNA_count[,-1]

## 转换成DGEList-object
dge <- DGEList(counts=counts)
metadata = read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/RNA_anatation.csv")
dim(RNA_count)
metadata$gene_name

x = dge
## Organising sample information

group <- as.factor(metadata$Response)

x$samples$group <- group

lane <- as.factor(rep(c("L004","L006","L008"), c(10,10,10)))
x$samples$lane <- lane
x$samples

## Organising gene annotations
geneid <- rownames(x)
genes <- AnnotationDbi::select(org.Hs.eg.db, 
                               keys=geneid, 
                               columns=c("SYMBOL", "ENTREZID", "GENENAME"), 
                               keytype="ENSEMBL", 
                               multiVals = "first")
head(genes)

# To resolve duplicate gene IDs one could combine all chromosome 
# information from the multi-mapped genes.
genes <- genes[!duplicated(genes$ENSEMBL),]
x$genes <- genes
x

## Data pre-processing

### Transformations from the raw-scale

# 计算RPKM/FPKM
# 首先，计算每个基因的RPKM（Reads Per Kilobase Million）或FPKM（Fragments Per Kilobase Million），
# 这是TPM计算的一个中间步骤。RPKM和FPKM考虑了转录本长度和总读数，但它们不允许跨样本的直接比较。

rpkm <- function(counts, geneLengths) {
  countsPerKb <- counts / (geneLengths / 1000)  # 将基因长度从bp转换为kb
  countsPerKb / sum(countsPerKb) * 1e6  # 标准化到每百万测序读数
}

# 应用RPKM函数
rpkmValues <- apply(counts, 2, rpkm, geneLengths)

# 转换为TPM
# 接下来，将RPKM/FPKM值转换为TPM。TPM首先对每个基因的RPKM/FPKM进行标准化，然后乘以1e6（每百万）进行缩放。
tpm <- function(rpkmValues) {
  # Sum of RPKM values calculated for each sample (column)
  sumRpkm <- colSums(rpkmValues)
  # Each RPKM value was then divided by the sum of the samples in which 
  # it was found and multiplied by 1e6 to calculate the TPM
  rpkmValues / sumRpkm * 1e6
}

# 应用RPKM函数
rpkmValues <- apply(counts, 2, rpkm, geneLengths)
# 应用TPM函数
tpmValues <- tpm(rpkmValues)

tpm <- tpm(x$counts)

filterByExpr()

L <- mean(x$samples$lib.size) * 1e-6
M <- median(x$samples$lib.size) * 1e-6
c(L, M)
## Removing genes that are lowly expressed
table(rowSums(x$counts==0)==24)

filteredData <- tpm[rowMeans(tpm) > 1, ]

lcpm = log2(filteredData + 1)

library(RColorBrewer)

lcpm.cutoff = 0.0
nsamples <- ncol(x)
col <- brewer.pal(nsamples, "Paired")
par(mfrow=c(1,2))
plot(density(lcpm[,1]), col=col[1], lwd=2, ylim=c(0,0.6), las=2, main="", xlab="")
title(main="A. Raw data", xlab="Log-cpm")
abline(v=lcpm.cutoff, lty=3)
for (i in 2:nsamples){
  den <- density(lcpm[,i])
  lines(den$x, den$y, col=col[i], lwd=2)
}
legend("topright", samplenames, text.col=col, bty="n")
lcpm <- cpm(x, log=TRUE)
plot(density(lcpm[,1]), col=col[1], lwd=2, ylim=c(0,0.6), las=2, main="", xlab="")
title(main="B. Filtered data", xlab="Log-cpm")
abline(v=lcpm.cutoff, lty=3)
for (i in 2:nsamples){
  den <- density(lcpm[,i])
  lines(den$x, den$y, col=col[i], lwd=2)
}
legend("topright", samplenames, text.col=col, bty="n")

## ------------------ Figure-1 ---------------
driverExpression <- read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/DEGs/version-filter5-thresh30/dot_plot.csv")

ggplot(driverExpression,aes(x=reorder(SYMBOL,log2FoldChange),y=(log2FoldChange),color=group))+
  geom_point(aes(size= -log10(padj)))+
  geom_hline(yintercept=0,color="black", linetype="dotted")+
  labs(x="",y="log FC pCR")+
  coord_flip()+
  scale_colour_manual(values = c("#FB6542","#375E97"))+
  scale_size_continuous(name=expression(italic(-log[10]~FDR)),breaks = c(2:4))+
  guides(color="none")+
  theme_manuscript(base_size = figure_font_size)+
  theme(panel.grid.major.y = element_blank(),
        axis.text.y = element_text(face="italic"),
        plot.margin = unit(c(1.1,1.5,0,0.5), "lines"))

pathways <- read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/DEGs/version-filter5-thresh30/pathway/Reactome_pathway.csv")

# ggplot(pathways,aes(y=NES,x=reorder(pathway,NES),label = pathway))+
#   geom_text(aes(y = pathway, hjust = NES > 0),size=(figure_font_size)/(14/5))+ 
#   geom_bar(stat="identity",aes(fill=group))+
#   geom_hline(yintercept = 0)+
#   coord_flip(ylim = c(-4,4))+
#   labs(y = "Normalised enrichment score (pCR)", x = "",title="")+
#   scale_fill_manual(values = c("#FB6542","#375E97"),name="Expression: pCR",labels=c("Up","Down"))+
#   scale_x_discrete(breaks = NULL)+
#   theme_manuscript(base_size = figure_font_size)+
#   theme(panel.grid.major = element_blank(),
#         axis.line.y = element_blank(),
#         plot.margin = unit(c(0.1,0,0.05,0), "lines"))

ggplot(pathways, aes(x = reorder(pathway, NES), y = NES)) +
  geom_bar(stat = "identity", aes(fill = group), width = 0.7) + 
  geom_text(aes(label = pathway, y = ifelse(NES > 0, NES - 4.2, NES + 1.2)), hjust = -0.1, size = 4) +
  geom_hline(yintercept = 0) + 
  coord_flip() + 
  labs(y = "Normalised enrichment score (NES)", x = "", title = "Reactome pathway enrichment: R vs NR") +
  scale_fill_manual(values = c("#375E97", "#FB6542"), name = "Expression: NES", labels = c("Down", "Up")) +
  scale_x_discrete(breaks = NULL)+
  theme_manuscript(base_size = figure_font_size)+
  theme(panel.grid.major.y = element_blank(),
        axis.text.y = element_text(face="italic"),
        plot.margin = unit(c(1.1,1.5,0,0.5), "lines"))











library (ggplot2)
library (ggpubr)

figure_font_size=12

theme_manuscript <- function(base_size=12, base_family="arial") {
  library(grid)
  (ggthemes::theme_foundation(base_size=base_size)
    + theme(plot.title = element_text(face = "bold",hjust = 0.5,size = base_size),
            panel.background = element_rect(colour = NA),
            plot.background = element_rect(colour = NA),
            panel.border = element_rect(colour = NA),
            axis.title.y = element_text(angle=90,vjust =2,size = base_size),
            axis.title.x = element_text(vjust = -0.2,size = base_size),
            axis.text = element_text(size = base_size), 
            axis.line = element_line(colour="black"),
            axis.ticks = element_line(),
            panel.grid.major = element_line(colour="#f0f0f0"),
            panel.grid.minor = element_blank(),
            legend.key = element_rect(colour = NA),
            legend.position = "bottom",
            legend.direction = "horizontal",
            legend.key.size= unit(0.5, "cm"),
            legend.spacing = unit(0, "cm"),
            strip.background=element_rect(colour="#f0f0f0",fill="#f0f0f0"),
            strip.text = element_text(size=base_size)
    ))
}

scale_fill_RCB <- function(...){
  library(scales)
  discrete_scale("fill","sjs",manual_pal(values = c("#20A39E","#ffe671","#fdb462","#ef3b2c","#662506","#a6cee3","#fb9a99","#984ea3","#ffff33")), ...)
}

scale_fill_pCR_RD <- function(...){
  library(scales)
  discrete_scale("fill","sjs",manual_pal(values = c("#20A39E","#fdb462")), ...)
}

scale_colour_RCB <- function(...){
  library(scales)
  discrete_scale("colour","sjs",manual_pal(values = c("#47A8BD","#ffe671","#fdb462","#ef3b2c","#662506","#5AB4E5","#fb9a99","#984ea3","#ffff33")), ...)
}

scale_colour_pCR_RD <- function(...){
  library(scales)
  discrete_scale("colour","sjs",manual_pal(values = c("#20A39E","#fdb462")), ...)
}


