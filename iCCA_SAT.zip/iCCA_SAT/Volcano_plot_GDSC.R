#=========================================================================
# Panel=Fig7 - Scatter plot for Clinical and xCell signature overall survival
#=========================================================================
library(ggplot2)
library(ggrepel)
# library(showtext)


get_path <- function() {
  
  x <- readClipboard()
  x <- gsub('^\"|\"$', '', x)
  x_clean <- gsub("\\\\", "/", x)
  rstudioapi::insertText(paste0("# ", x_clean, "\n"))
  
  return(x_clean)
}



pathh <- get_path()

# genes <- read.csv("/Volumes/Extreme_Pro/Samsung_T5/pan-cancer/基于基因蛋白组的泛癌研究/Data/4-Proteomics/5-drug-target-screening/Single_Tumor_DEP/Pan-cancer-ADC_target_prior_table_top5.csv", header = TRUE)
genes <- read.csv("/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/Chemo_Immuno/GDSC/Oxaliplatin_combined_sensitivity.csv")

colnames(genes)
# genes$logFC <- -genes$logFC
genes$Significant <- ifelse(genes$P.value < 0.05 & genes$Effect.size > 0.25, "Increased resistance",
                            ifelse(genes$P.value < 0.05 & genes$Effect.size < -0.25, "Increased sensitivity", "Not Sig"))

genes$size = ifelse(genes$Significant == "Increased resistance" | genes$Significant == "Increased sensitivity" , abs(genes$Effect.size), 0.3)


ggplot(genes, aes(x = Effect.size , y = -log10(P.value), size = size)) +
  geom_point(aes(color = Significant)) +
  scale_size_continuous(range = c(2,4))+
  scale_color_manual(values = c("#FB6542","#375E97","#8E8E8E")) + # ("gray", "#7AA9CE") c( "#EA686B","#7AA9CE","gray")) c("#515151", "red"))
  theme_bw(base_size = 12) + theme(legend.position = "right") +
  geom_text_repel(
    data = subset(genes, Significant != "NA"),
    aes(label = Cancer.feature),
    size = 5,
    box.padding = unit(0.35, "lines"),
    point.padding = unit(0.3, "lines")
  )+
  theme(panel.border = element_blank(), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+
  ggtitle("The Oxaliplatin treatment IC50 in GDSC2 dataset")+
  theme(axis.text.x=element_text(angle=0,hjust = 0.6,colour="black",family="Arial",size=16), #设置x轴刻度标签的字体显示倾斜角度为15度，并向下调整1(hjust = 1)，字体簇为Times大小为20
        axis.title.x=element_text(angle=0,hjust = 0.5,colour="black",family="Arial",size=16),
        axis.text.y=element_text(family="Arial",size=16,face="plain"), #设置y轴刻度标签的字体簇，字体大小，字体样式为plain
        axis.title.y=element_text(family="Arial",size = 20,face="plain"), #设置y轴标题的字体属性
        panel.border = element_blank(),axis.line = element_line(colour = "black",size=0.8), #去除默认填充的灰色，并将x=0轴和y=0轴加粗显示(size=1)
        legend.text=element_text(face="plain", family="Arial", colour="black",  #设置图例的子标题的字体属性
                                 size=12),
        legend.title=element_text(face="plain", family="Arial", colour="black", #设置图例的总标题的字体属性
                                  size=12),
        panel.grid.major = element_blank(),   #不显示网格线
        panel.grid.minor = element_blank())+
  geom_hline(yintercept = 1.301,color = 'gray', linetype="dashed")+
  geom_vline(xintercept = -0.2,color = 'gray', linetype="dashed") +
  geom_vline(xintercept = 0.2,color = 'gray', linetype="dashed") 


# genes$size = ifelse(genes$Significant == "Pan-cacner-overexpressed" | genes$Significant == "Single-tumor-overexpressed" , abs(genes$Frequency), 0.2)

# ggplot(genes, aes(x = Effect.size, y = -log10(P.value)), size = size) +
#   geom_point(aes(color = Significant)) +
#   scale_size_continuous(range = c(2,4))+
#   scale_color_manual(values = c("#FB6542","#375E97","#8E8E8E" )) + # ("gray", "#7AA9CE") c( "#EA686B","#7AA9CE","gray")) c("#515151", "red"))
#   theme_bw(base_size = 12) + theme(legend.position = "right") +
#   geom_text_repel(
#     data = subset(genes, Significant != "NA"),
#     aes(label = Cancer.feature),
#     size = 5,
#     max.overlaps = getOption("ggrepel.max.overlaps", default = 20),
#     box.padding = unit(0.35, "lines"),
#     point.padding = unit(0.3, "lines")
#   )+
#   theme(panel.border = element_blank(), panel.grid.major = element_blank(),
#         panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+
#   ggtitle("The Gemcitabine treatment IC50 in GDSC1 dataset")+
#   theme(axis.text.x=element_text(angle=0,hjust = 0.6,colour="black",family="Arial",size=16), #设置x轴刻度标签的字体显示倾斜角度为15度，并向下调整1(hjust = 1)，字体簇为Times大小为20
#         axis.title.x=element_text(angle=0,hjust = 0.5,colour="black",family="Arial",size=16),
#         axis.text.y=element_text(family="Arial",size=16,face="plain"), #设置y轴刻度标签的字体簇，字体大小，字体样式为plain
#         axis.title.y=element_text(family="Arial",size = 20,face="plain"), #设置y轴标题的字体属性
#         panel.border = element_blank(),axis.line = element_line(colour = "black",size=0.8), #去除默认填充的灰色，并将x=0轴和y=0轴加粗显示(size=1)
#         legend.text=element_text(face="plain", family="Arial", colour="black",  #设置图例的子标题的字体属性
#                                  size=12),
#         legend.title=element_text(face="plain", family="Arial", colour="black", #设置图例的总标题的字体属性
#                                   size=12),
#         panel.grid.major = element_blank(),   #不显示网格线
#         panel.grid.minor = element_blank())+
#   geom_hline(yintercept = 1.3,color = 'gray', linetype="dashed")+
#   # geom_vline(xintercept = -0.35,color = 'gray', linetype="dashed") +
#   geom_vline(xintercept = 0.25,color = 'gray', linetype="dashed") +
#   geom_vline(xintercept = -0.25,color = 'gray', linetype="dashed") +
#   scale_x_continuous(limits = c(-2, 2)) 
# 


