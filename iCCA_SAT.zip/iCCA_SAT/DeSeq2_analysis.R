library(DESeq2)
library(Homo.sapiens)
library(org.Hs.eg.db)
library(ggplot2)
library(tidyr)
library(dplyr)
library(ComplexHeatmap)
library(AnnotationDbi)
library(clusterProfiler)
library(enrichplot)
library(signatureSearch)
# -----------------------  Loading and pre-processing data  ---------------------------------
countdata <- read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/raw_DATA/iCCA_merged_counts_sorted_filter5_thresh30.csv", header=TRUE, row.names=1)
metadata <- read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/RNA_metadata.csv", header=TRUE)

countmatrix <- as.matrix(countdata)
# rownames(countmatrix) <- countdata[ , 1]
colnames(metadata) <- c("sample","condition", 'type', 'progress')

# factors 
condition <- metadata['condition']
type <- metadata['type']

# ---------------------------  Analysis with DESeq2 ----------------------------------------

# Create a coldata frame and instantiate the DESeqDataSet. See ?DESeqDataSetFromMatrix
coldata = data.frame(row.names=colnames(countmatrix), condition, type)

dds <- DESeqDataSetFromMatrix(countData=countmatrix, colData=coldata, design= ~condition)

# Low Expression Gene Filtering
# keep <- rowSums(counts(dds) >= 10) >= 3   
# dds <- dds[keep, ] 

# Run the DESeq pipeline
dds <- DESeq(dds)

# DESeq2 DOES NOT return normalized counts, but we can explicitly command it 
ndds <- estimateSizeFactors(dds)
norm.counts <- counts(ndds, normalized=TRUE)

#saving 
# write.csv(norm.counts,'/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/norm_counts.csv')

# checking 
head(norm.counts)

rld <- rlogTransformation(dds)  ## 得到经过DESeq2软件normlization的表达矩阵！
exprSet_new=assay(rld)
# par(cex = 0.7)
# n.sample=ncol(exprSet)
# if(n.sample>40) par(cex = 0.5)
exprSet <- assay(ndds)
cols <- rainbow(ncol(norm.counts)*1.2)
par(mfrow=c(2,2))
boxplot(assay(ndds), col = cols,main="Raw expression value",las=2)
boxplot(exprSet_new, col = cols,main="Normalized expression value",las=2)
hist(exprSet)
hist(exprSet_new)

par(mfrow=c(1,1))


### C) Calculating statistics 
# We will consider p-value $< 0.05$ as significant in this case:

res05 <- results(dds, contrast=c("condition","Non-responder","Responder"), alpha=0.1)
summary(res05)

### Annotate gene symbols

# Add gene full name
# res05$description <- mapIds(x = org.Hs.eg.db,
#                               keys = row.names(res05),
#                               column = "GENENAME",
#                               keytype = "ENSEMBL",
#                               multiVals = "first")

# Add gene symbol
# res05$symbol <- mapIds(x = Homo.sapiens,
#                          keys = row.names(res05),
#                          column = "SYMBOL",
#                          keytype = "ENSEMBL",
#                          multiVals = "first")

## Organising gene annotations
geneid <- rownames(res05)
genes <- AnnotationDbi::select(org.Hs.eg.db, 
                keys=geneid, 
                columns=c("SYMBOL", "ENTREZID", "GENENAME"), 
                keytype="ENSEMBL", 
                multiVals = "first")
head(genes)

# To resolve duplicate gene IDs one could combine all chromosome 
# information from the multi-mapped genes.
genes <- genes[!duplicated(genes$ENSEMBL),]

res05 <- cbind(genes, res05)


### D) PCA
vsd <- vst(dds, blind=FALSE)
rld <- rlog(dds, blind=FALSE)

plotPCA(vsd, intgroup=c("condition", "type", "progress")) + 
  theme_bw() +
  geom_point(size = 2) +
  coord_fixed(ratio = 2.3)  +
  ggtitle(label = "Principal Component Analysis (PCA)", 
          subtitle = "Top 1000 most variable genes")

# 提取变换后的数据并计算 PCA
pca_result <- prcomp(t(assay(rld)))

# 提取 PCA 分数
pca_scores <- as.data.frame(pca_result$x)

# 添加样本名作为新列
pca_scores$sample <- rownames(pca_scores)

# 从 DESeqDataSet 提取样本信息
sample_info <- data.frame(sample = rownames(colData(dds)), condition = dds$condition, type = metadata$type, progress=metadata$progress)

# 合并 PCA 分数和样本信息
pca_data <- merge(pca_scores, sample_info, by = "sample")

pca_result <- prcomp(assay(rld))
percentVar <- pca_result$sdev^2 / sum(pca_result$sdev^2) * 100
percentVar[1:5] # 查看前5个主成分的解释的方差百分比
# percentVar <- round(100 * attr(percentVar, "percentVar"))

ggplot(pca_data, aes(x= PC1, y = PC2)) +
  geom_point(size= 3, aes(shape=type, fill=condition)) +
  scale_fill_manual(values = c("#E69F00", "#56B4E9", "#7AA9CE","red")) +
  scale_shape_manual(values=c(21, 23, 25, 22)) +
  geom_text_repel(size= 3.5, aes(label=type, colour=condition)) + 
  scale_color_discrete() +
  xlab(paste0("PC1: ", round(percentVar[1], 1), "% variance")) +
  ylab(paste0("PC2: ", round(percentVar[2], 1), "% variance")) +
  coord_fixed() +
  ggtitle("PCA with Scaled data")

# ggsave("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/pca_plot.pdf", width = 6, height = 6)

# ddsMat_rlog <- rlog(dds, blind = FALSE)
# # Plot PCA by column variable
# plotPCA(ddsMat_rlog, intgroup = "condition", ntop = 500) +
#   theme_bw() + # remove default ggplot2 theme
#   geom_point(size = 2) + # Increase point size
#   # scale_y_continuous(limits = c(-5, 5)) + # change limits to fix figure dimensions
#   ggtitle(label = "Principal Component Analysis (PCA)", 
#           subtitle = "Top 500 most variable genes")


# save the result and filter by p-value and fold change
# write.csv(as.data.frame(res05), 
#           file="/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/DEG-results.csv")


### E) Filtering results 
# We will remove results with adjusted p-value below $0.05$ or NA (because of low read counts to a gene DESeq2 input NA) 
# and also select only genes with absolute Fold Change $> 2$: 
results = read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/DEG-results.csv", row.names = 1)
filter <- subset(results, padj <= 0.05 & abs(log2FoldChange) > 1)
filter

write.csv(filter, file="/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/results_pval-0.05_FC-gt-2.csv")

## ----------- Visualization of DEGs with heatmap and volcano plot  --------------

### volcano plot

library(ggrepel)

genes <- read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/DEGs/version-filter5-thresh30/DEG-results.csv", header = TRUE)
genes <- genes %>% filter(!is.na(SYMBOL))

colnames(genes)
genes$Significant <- ifelse(genes$pvalue < 0.05 & genes$log2FoldChange > 1, "Up-regulation",
                            ifelse(genes$pvalue < 0.05 & genes$log2FoldChange < -1, "Down-regulation","Not Sig"))
genes$select = ifelse(genes$Significant == "Not Sig" , "Not Sig","select")
ggplot(genes, aes(x = log2FoldChange, y = -log10(pvalue))) +
  geom_point(aes(color = Significant, size = -log10(pvalue))) +
  scale_size_continuous(range = c(1, 3))+
  scale_color_manual(values = c("#375E97","#828282","#FB6542")) + # ("gray", "#7AA9CE") c( "#EA686B","#7AA9CE","gray"))
  theme_bw(base_size = 12) + theme(legend.position = "right") +
  geom_text_repel(
    data = subset(genes, select == "select"),
    aes(label = SYMBOL, colour = Significant),
    size = 4.5,
    box.padding = unit(0.35, "lines"),
    point.padding = unit(0.3, "lines")
  )+
  theme(panel.border = element_blank(), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+
  ggtitle("DEG Analysis between R/NR groups")+
  theme(axis.text.x=element_text(angle=0,hjust = 0.6,colour="black",family="Arial",size=16), #设置x轴刻度标签的字体显示倾斜角度为15度，并向下调整1(hjust = 1)，字体簇为Times大小为20
        axis.title.x=element_text(angle=0,hjust = 0.5,colour="black",family="Arial",size=16),
        axis.text.y=element_text(family="Arial",size=16,face="plain"), #设置y轴刻度标签的字体簇，字体大小，字体样式为plain
        axis.title.y=element_text(family="Arial",size = 20,face="plain"), #设置y轴标题的字体属性
        panel.border = element_blank(),axis.line = element_line(colour = "black",size=0.8), #去除默认填充的灰色，并将x=0轴和y=0轴加粗显示(size=1)
        legend.text=element_text(face="plain", family="Arial", colour="black",  #设置图例的子标题的字体属性
                                 size=12),
        legend.title=element_text(face="plain", family="Arial", colour="black", #设置图例的总标题的字体属性
                                  size=12),
        panel.grid.major = element_blank(),   #不显示网格线
        panel.grid.minor = element_blank())+
  geom_hline(yintercept = 1.301,color = 'gray', linetype="dashed")+
  geom_vline(xintercept = -1,color = 'gray', linetype="dashed") +
  geom_vline(xintercept = 1,color = 'gray', linetype="dashed") 
# panel.border = element_rect(colour = "black", fill=NA, size=1)

# ggsave("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/figs/volcano_plot.pdf", width = 6, height = 6)

# MA Plot
plotMA(res05, ylim = c(-5, 5))

plotMA(res05, alpha = 0.25, colSig = 'red', colLine = 'skyblue')

# Plot Dispersions
plotDispEsts(dds)


## Pathway enrichment analysis by Pyomic
# 首先，我们将log2FoldChange转换为排名
deseq2_result <- subset(res05, is.na(SYMBOL) == FALSE)
deseq2_result$rank <- -log10(deseq2_result$pvalue) * sign(deseq2_result$log2FoldChange)

# 准备一个向量，包含所有基因的排名
gene_list <- deseq2_result$rank
names(gene_list) <- deseq2_result$ENTREZID

# 确保基因列表是按照排名从高到低排序的
gene_list <- sort(gene_list, decreasing = TRUE)

# 进行GSEA分析
gsea_result <- gseKEGG(geneList = gene_list,
                       organism = "hsa",  # 如果分析的不是人类，需要更改
                       nPerm = 1000,      # 进行1000次置换测试
                       minGSSize = 5,    # 基因集最小大小
                       maxGSSize = 500,   # 基因集最大大小
                       pAdjustMethod = "BH",
                       pvalueCutoff = 0.05, 
                       verbose = TRUE)

GSEA_KEGG <- setReadable(gsea_result, org.Hs.eg.db, keyType = "ENTREZID")
# # 查看结果
print(head(GSEA_KEGG))
gsea_df <- as.data.frame(GSEA_KEGG)
# 
# geneSymbols <- bitr(gsea_result$core_enrichment, fromType = "ENTREZID", toType = "SYMBOL", OrgDb = org.Hs.eg.db)
# # 查看转换结果
# head(geneSymbols)
# 
write.csv(gsea_df, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/DEGs/version-filter5-thresh30/DEG-results-KEGG_pathways.csv")



# Enrich genes using the Gene Onotlogy
GSEGO_BP <- gseGO(gene = gene_list, 
                      OrgDb = 'org.Hs.eg.db', 
                      ont = "BP",
                      nPerm = 1000,      # 进行1000次置换测试
                      minGSSize = 5,    # 基因集最小大小
                      maxGSSize = 250,   # 基因集最大大小
                      pAdjustMethod = "BH",
                      pvalueCutoff = 0.25, 
                      verbose = TRUE)# Plot resultsbarplot(go_enrich, 


GSEGO_BP <- setReadable(GSEGO_BP, org.Hs.eg.db, keyType = "ENTREZID")
GSEGO_BP <- as.data.frame(GSEGO_BP) 
# write.csv(GSEGO_BP, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/DEGs/version-filter5-thresh30/DEG-results-GO_BP_pathways.csv")


GSE_Reactome <- gseReactome(geneList = gene_list,
                        organism = "human",
                        exponent = 1,
                        nPerm = 1000,
                        minGSSize = 10,
                        maxGSSize = 500,
                        pvalueCutoff = 0.05,
                        pAdjustMethod = "BH",
                        verbose = TRUE,
                        readable = T
                      )

# GSE_Reactome <- setReadable(GSE_Reactome, org.Hs.eg.db, keyType = "ENTREZID")
GSEGO_React <- GSE_Reactome@result
# write.csv(GSEGO_React, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/DEGs/version-filter5-thresh30/DEG-results-Reactome-pathways-up.csv")


gene_list_down <- sort(-gene_list, decreasing = T)
GSE_Reactome <- gseReactome(geneList = gene_list_down,
                            organism = "human",
                            exponent = 1,
                            nPerm = 1000,
                            minGSSize = 10,
                            maxGSSize = 500,
                            pvalueCutoff = 0.25,
                            pAdjustMethod = "BH",
                            verbose = TRUE,
                            readable = T
)

# GSE_Reactome <- setReadable(GSE_Reactome, org.Hs.eg.db, keyType = "ENTREZID")
GSEGO_React_down <- GSE_Reactome@result
write.csv(GSEGO_React_down, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/DeSeq2/DEGs/version-filter5-thresh30/DEG-results-Reactome-pathways-down.csv")




#further filter out the significant gene sets and order them by NES scores.
# GO pathway enrichment
GSEA_BP_df <- as.data.frame(GSEGO_BP) %>% dplyr::filter(abs(NES)>1 & pvalue<0.05 & qvalues<0.25)
GSEA_BP_df <- GSEA_BP_df[order(GSEA_BP_df$NES, decreasing = T),]
p <- gseaplot(GSEGO_BP, GSEA_BP_df$ID[1], by='all', title = GSEA_BP_df$Description[1], color.vline = 'gray50', color.line='red', color='black') #by='runningScore/preranked/all'
p <- p+annotate(geom = 'text', x = 0.87, y =0.85, color='red', fontface = 'bold', size= 4,
                label=paste0('NES= ', round(GSEA_BP_df$NES[1], 1), '\n', 'p.adj= ', round(GSEA_BP_df$p.adjust[1], 2)))+
  theme(panel.grid = element_line(colour = 'white'))
p
# KEGG pathway enrichment
GSEA_KEGG_df <- as.data.frame(GSEA_KEGG) %>% dplyr::filter(abs(NES)>1 & pvalue<0.05 & qvalues< 0.25)
GSEA_KEGG_df <- GSEA_KEGG_df[order(GSEA_KEGG_df$NES, decreasing = T),]
i= 1
p <- enrichplot::gseaplot2(GSEA_KEGG, geneSetID = GSEA_KEGG_df$ID[i], pvalue_table = F, ES_geom = 'line')+
  annotate('text', x = 0.87, y =0.85, color='red', fontface = 'bold', size= 4,
           label=paste0('NES= ', round(GSEA_KEGG_df$NES[i], 1), '\n', 'p.adj= ', round(GSEA_KEGG_df$p.adjust[1], 2)))+
  labs(title = GSEA_KEGG_df$Description[i])+theme(plot.title = element_text(hjust = 0.5))
p

GSEA_KEGG$Description
# enrichplot::gseaplot2(GSEA_KEGG, c(1,5,6,8))
enrichplot::gseaplot2(GSEA_KEGG, geneSetID = c(9,17,12), color = c('red','#56AF61','#3C679E')) #
