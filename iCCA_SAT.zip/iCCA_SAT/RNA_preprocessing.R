library(Glimma)
library(edgeR)
library(dplyr)
library(Homo.sapiens)
library(GenomicFeatures)
library(BiocFileCache) 
library(rtracklayer)
library(plyr)
library(SummarizedExperiment)

## Reading in count-data
RNA_count = read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/raw_DATA/iCCA_merged_counts_sorted_filter5_thresh30.csv")
rownames(RNA_count) = RNA_count[,1]
counts = RNA_count[,-1]

## 转换成DGEList-object
dge <- DGEList(counts=counts, genes = rownames(RNA_count))

## metadata
metadata = read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/RNA_anatation.csv")
dim(RNA_count)
metadata$Sample_ID
group <- metadata$Response

dge$samples$group <- group

# pre-filter 0 counts

filter_counts <- function(data, N) {
  # 检查输入参数
  # if (!is.data.frame(data)) {
  #   stop("data must be a data frame")
  # }
  if (!is.numeric(N)) {
    stop("N must be numeric")
  }
  
  count_sum <- apply(data, 1, function(x) sum(x >= 1))
  filtered_data <- data[count_sum >= N, ]
  return(filtered_data)
}

dge = filter_counts(dge, 15)

##  -------------  Data pre-processing.  --------------

# 转换成FPKM值并归一化（normalization）

#download v36 of the GENCODE annotation
# library(BiocFileCache) 
gencode_file = 'gencode.v36.annotation.gtf.gz'
gencode_link = paste(
  'ftp://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_36',
  gencode_file,
  sep = '/'
)
bfc <- BiocFileCache() 
gencode_path <- bfcrpath(bfc, gencode_link) 


gtf = import.gff(gencode_path, format = 'gtf', genome = 'GRCm38.71', feature.type = 'exon')
#split records by gene to group exons of the same gene
grl = reduce(split(gtf, elementMetadata(gtf)$gene_id))
gene_lengths = ldply(grl, function(x) {
  #sum up the length of individual exons
  return(c('gene_length' = sum(width(x))))
}, .id = 'ensembl_gene_id')


# 我们获取了基因的Ensembl IDs和gene type注释信息以便于下游分析。直接从GTF文件里获得的
# Ensembl IDs末尾带有版本号，我们需要将其去掉以转换为正式的Ensembl IDs。

#extract information on gene biotype
genetype = unique(elementMetadata(gtf)[, c('gene_id', 'gene_type')])
colnames(genetype)[1] = 'ensembl_gene_id'
gene_lengths = merge(genetype, gene_lengths)

#remove ENSEMBL ID version numbers
gene_lengths$ensembl_gene_id = gsub('\\.[0-9]*', '', gene_lengths$ensembl_gene_id)
saveRDS(gene_lengths, file = 'gene_lengths_gencode_v36.rds')
gene_lengths

# SummarizedExperiment对象可以存储基因的注释信息，因此我们需要把Ensembl IDs、gene length
# 和gene type加进去。类似的，我们也要把这些注释信息加到DGEList对象中。
# library(SummarizedExperiment)

#allocate rownames for ease of indexing
rownames(gene_lengths) = gene_lengths$ensembl_gene_id

# 将gene length添加到DGEList对象中
dge$genes$gene_length <- gene_lengths[match(rownames(dge), rownames(gene_lengths)), "gene_length"]

# 将gene biotype添加到DGEList对象中
dge$genes$gene_biotype <- gene_lengths[match(rownames(dge), rownames(gene_lengths)), "gene_type"]

#annotate gene lengths for the DGE object
dge$genes$gene_length = gene_lengths[rownames(dge), 'gene_length']

# 计算normalisation factors之后我们就可以将数据转换成RPKM/FPKM值了。只要特征数量（行）
# 和样本数量（列）相同，SummarizedExperiment对象可以同时存储多层数据。因此我们直接将
# FPKM值存在已建立的SummarizedExperiment对象aml_se中。

# Calculate CPM (Counts Per Million) - which accounts for library size differences
cpm <- cpm(dge, normalized.lib.sizes=TRUE)

# calculate RPKM/FPKM
fpkm = edgeR::rpkm(dge)

fpkm[is.na(fpkm)] = 0

fpkm_to_tpm <- function(fpkm){
  exp(log(fpkm) - log(sum(fpkm)) + log(1e6))
  }

tpm <- apply(fpkm,2,fpkm_to_tpm)
colSums(tpm, na.rm = T)

dge$fpkm <- fpkm
dge$tpm <- tpm

## adds an offset to the CPM values before converting to the log2-scale. 
L <- mean(dge$samples$lib.size) * 1e-6
M <- median(dge$samples$lib.size) * 1e-6
c(L, M)

## -------------- Removing genes that are lowly expressed ---------------

# 计算每个基因在至少一个样本中表达量大于1的比例
# prop_expressed = rowMeans(edgeR::cpm(dge) > 5)
# keep = prop_expressed >= 0.5
# dge_filtered = dge[keep, ]
# 使用nrow来获取过滤后的行数（基因数）
# filtered_gene_count = nrow(edgeR::cpm(dge[keep, ]))

# 使用默认的方式
keep.exprs <- filterByExpr(dge, group=group)
dge_filtered <- dge[keep.exprs,, keep.lib.sizes=FALSE]

# 手动更新dge_filtered中的fpkm和tpm组件
dge_filtered$fpkm <- dge$fpkm[keep.exprs, ]
dge_filtered$tpm <- dge$tpm[keep.exprs, ]
dim(dge_filtered)

# 设置绘图参数
op = par(no.readonly = TRUE)
par(mfrow = c(1, 2))

# 绘制未过滤和过滤后的直方图
hist(edgeR::cpm(dge, log = TRUE), main = 'Unfiltered', xlab = 'logCPM')
abline(v = log(1), lty = 2, col = 2)

hist(edgeR::cpm(dge_filtered, log = TRUE), main = 'Filtered', xlab = 'logCPM')
abline(v = log(1), lty = 2, col = 2)

# 还原之前的绘图参数
par(op)

## Density plot

# Function to create a density plot comparing raw and filtered data
# 定义一个处理和绘图的辅助函数
process_and_plot_data <- function(data, col, ylim, las, title_text, xlab_text, samplenames, cutoff) {
  # 日志转换并移除NA值
  log_data <- log2(data)
  
  # 绘制第一个样本的密度图
  plot(density(log_data[, 1], na.rm = TRUE), col = col[1], lwd = 2, ylim = ylim, las = las, main = "", xlab = "")
  title(main = title_text, xlab = xlab_text)
  abline(v = cutoff, lty = 3)
  
  # 循环绘制剩余样本的密度图
  for (i in 2:ncol(data)) {
    lines(density(log_data[, i], na.rm = TRUE), col = col[i], lwd = 2)
  }
  
  # 添加图例
  if (!is.null(samplenames)) {
    legend("topright", samplenames, text.col = col, bty = "n")
  }
}

# 主函数
density_plot <- function(fpkm_data, tpm_data, samplenames = NULL, cutoff = 1, ylim = c(0, 0.4)) {
  library(RColorBrewer)
  
  # 设置颜色和绘图布局
  nsamples <- ncol(fpkm_data)
  col <- brewer.pal(nsamples, "Paired")
  par(mfrow = c(1, 2))
  
  # 处理和绘制FPKM数据
  process_and_plot_data(fpkm_data, col, ylim, 2, "A. Raw data", "Log-FPKM", samplenames, cutoff)
  
  # 处理和绘制TPM数据
  process_and_plot_data(tpm_data, col, ylim, 2, "B. Filtered data", "Log-TPM", samplenames, cutoff)
}

# dge_filtered$counts
density_plot(dge$fpkm, dge_filtered$tpm, samplenames=rownames(dge$samples), cutoff = 1, ylim = c(0, 0.22))

## ----------------  Normalising gene expression distributions. ----------------------

# 计算TMM标准化因子
dge_filtered_tmm = calcNormFactors(dge_filtered, method = 'TMM')
dge_filtered_tmm$samples$norm.factors

# Calculate CPM (Counts Per Million) - which accounts for library size differences
cpm <- cpm(dge_filtered_tmm, normalized.lib.sizes=TRUE)

# calculate RPKM/FPKM
fpkm = edgeR::rpkm(dge_filtered_tmm)

# calculate TPM
fpkm[is.na(fpkm)] = 0
tpm <- apply(fpkm, 2, fpkm_to_tpm)
colSums(fpkm, na.rm = T)
tpm <- sweep(dge_filtered_tmm$counts, 1, dge_filtered_tmm$genes$gene_length, "/") * 1e6 / colSums(dge_filtered_tmm$counts)
colSums(tpm, na.rm = T)

dge_filtered_tmm$fpkm_tnm <- fpkm
dge_filtered_tmm$tpm_tnm <- tpm


density_plot(dge_filtered_tmm$fpkm, dge_filtered_tmm$fpkm_tnm, samplenames=rownames(dge$samples), cutoff = 1, ylim = c(0, 0.22))

density_plot(dge_filtered$tpm, dge_filtered_tmm$tpm_tnm, samplenames=rownames(dge$samples), cutoff = 1, ylim = c(0, 0.22))

density_plot(dge_filtered$fpkm, dge_filtered_tmm$tpm, samplenames=rownames(dge$samples), cutoff = 1, ylim = c(0, 0.22))





drawFPKMBoxplots <- function(FPKM, FPKM_tnm, col, titles = c("Unnormalised data", "Normalised data")) {
  # 确保RColorBrewer包已加载，用于颜色
  if (!requireNamespace("RColorBrewer", quietly = TRUE)) {
    stop("需要RColorBrewer包，请先安装。")
  }
  
  # 设置绘图参数
  par(mfrow = c(1, 2))
  
  # 处理并绘制未标准化的FPKM数据
  boxplot(log2(FPKM), las = 2, col = col, main = "")
  title(main = paste("A. iCCA:", titles[1]), ylab = "Log-FPKM")
  
  # 处理并绘制标准化的FPKM数据
  boxplot(log2(FPKM_tnm), las = 2, col = col, main = "")
  title(main = paste("B. iCCA:", titles[2]), ylab = "Log-FPKM")
}

# col <- RColorBrewer::brewer.pal(length(colnames(dge_filtered_tmm)), "YlOrRd")
col <- brewer.pal(length(colnames(dge_filtered_tmm)), "Paired")
drawFPKMBoxplots(dge_filtered_tmm$fpkm, dge_filtered_tmm$fpkm_tnm, col)

drawFPKMBoxplots(dge_filtered_tmm$tpm, dge_filtered_tmm$tpm_tnm, col)

drawFPKMBoxplots(cpm, dge_filtered_tmm$fpkm_tnm, col)
## -------------------  Organising gene annotations   -----------------
# geneid <- rownames(dge_filtered_tmm)
# genes <- select(Homo.sapiens, keys=geneid, columns=c("SYMBOL", "TXCHROM"), 
#                 keytype="ENSEMBL")
# head(genes)

geneid <- rownames(dge_filtered_tmm)
genes <- AnnotationDbi::select(org.Hs.eg.db, 
                               keys=geneid, 
                               columns=c("SYMBOL", "ENTREZID", "GENENAME"), 
                               keytype="ENSEMBL", 
                               multiVals = "first")
head(genes)
# To resolve duplicate gene IDs one could combine all chromosome 
# information from the multi-mapped genes.
genes <- genes[!duplicated(genes$ENSEMBL),]

TPM_tnm = cbind(genes, dge_filtered_tmm$tpm_tnm)
write.csv(TPM_tnm, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/edgeR/RNA_matrix_TPM_tnm.csv")

FPKM_tnm = cbind(genes, dge_filtered_tmm$fpkm_tnm)
write.csv(FPKM_tnm, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/edgeR/RNA_matrix_FPKM_tnm.csv")


TPM = cbind(genes, dge_filtered_tmm$tpm)
write.csv(TPM, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/edgeR/RNA_matrix_TPM.csv")

FPKM = cbind(genes, dge_filtered_tmm$fpkm)
write.csv(FPKM, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/edgeR/RNA_matrix_FPKM.csv")


dge_filtered_tmm$genes <- genes
dge_filtered_tmm

## 删除 Symbol列中存在 NA 的所有行
updateDGEList <- function(dge, update_list = c('counts', 'fpkm', 'tpm')) {
  # 确定基于 $genes$SYMBOL 中的 NA 值要删除的行
  na_indices <- is.na(dge$genes$SYMBOL)
  
  # 遍历 update_list 中的每个元素，根据元素值选择更新对应的矩阵
  for (data_type in update_list) {
    # 检查指定的数据类型是否存在于 dge 对象中
    if (!is.null(dge[[data_type]])) {
      # 如果存在，根据 na_indices 删除对应行
      dge[[data_type]] <- dge[[data_type]][!na_indices, ]
    }
  }
  
  # 更新 $genes 组件以反映这些变化，如果它被包含在更新列表中
  if ('genes' %in% update_list) {
    dge$genes <- dge$genes[!na_indices, ]
  }
  
  # 返回更新后的 DGEList 对象
  return(dge)
}



# 要更新 counts, fpkm, 和 tpm，可以这样调用函数：
dge_filtered_tmm_updated <- updateDGEList(dge_filtered_tmm, update_list = c('counts', 'genes', 'fpkm', 'tpm', 'fpkm_tnm', 'tpm_tnm'))


## ---------------- Unsupervised clustering of samples ------------------

plotMDSWithGroups <- function(dge_list, group_column, col_set, main_title = "Sample Groups") {
  library(edgeR)
  library(RColorBrewer)
  
  # 从DGEList对象中提取分组信息
  group <- factor(dge_list$samples[[group_column]])
  
  # 确定分组的数量，并生成颜色映射
  num_groups <- nlevels(group)
  color_map <- brewer.pal(num_groups, col_set)
  
  # 将颜色映射应用到分组上
  col.group <- color_map[as.integer(group)]
  
  # 绘制MDS图，为不同组的点指定颜色
  plotMDS(log2(dge_list$tpm_tnm + 1), labels = levels(group), col = col.group)
  title(main = main_title)
  
  # 添加图例
  # legend("topright", legend = levels(group), fill = color_map, title = "Group")
}

# 使用示例
# 假设你的DGEList对象名为dge_filtered_tmm_updated，samples组件中有一个名为"group"的列
# display.brewer.all()
plotMDSWithGroups(dge_filtered_tmm_updated, "group",col_set="Set1", "A. Sample groups")


glMDSPlot(log(dge_filtered_tmm_updated$counts + 1), labels=paste(rownames(dge_filtered_tmm_updated$samples)), 
          groups=dge_filtered_tmm_updated$samples[,c(1,4)], launch=T)


## -----------------  Differential expression analysis  ------------------
group <- metadata$Response
design <- model.matrix(~0+group)
colnames(design) <- gsub("group", "", colnames(design))
design

# set up in limma using the makeContrasts function.
contr.matrix <- makeContrasts(
  Non_respondervsResponder = Non_responder-Responder, 
  levels = colnames(design))

contr.matrix

## Removing heteroscedascity from count data

# 检查并去除含有 NA 值的行
tpm_clean <- dge_filtered_tmm_updated$tpm_tnm[complete.cases(dge_filtered_tmm_updated$tpm_tnm), ]

# 确保 design 矩阵的行数与 fpkm_clean 的行数相匹配
# 如果使用模型设计矩阵，可能也需要相应地调整这个矩阵
par(mfrow=c(1,2))
# 使用 voom 转换数据
v <- voom(dge_filtered_tmm_updated, design, plot=TRUE)

vfit <- lmFit(v, design)
vfit <- contrasts.fit(vfit, contrasts=contr.matrix)
efit <- eBayes(vfit)
plotSA(efit, main="Final model: Mean-variance trend")


summary(decideTests(efit))

tfit <- treat(vfit, lfc=1)
dt <- decideTests(tfit)
summary(dt)

## Normalising gene expression distributions
# FPKM
par(mfrow=c(1,2))
rownames(FPKM) <- FPKM[,1]
FPKM_processed <- FPKM[,-c(1,2,3)]
boxplot(log2(FPKM_processed), las=2, col=col, main="")
title(main="A. iCCA: Unnormalised data",ylab="Log-FPKM")

rownames(FPKM_tnm) <- FPKM_tnm[,1]
FPKM_tnm_processed <- FPKM_tnm[,-c(1,2,3)]
boxplot(log2(FPKM_tnm_processed), las=2, col=col, main="")
title(main="B. iCCA: Normalised data",ylab="Log-FPKM")

# TPM
par(mfrow=c(1,2))
rownames(TPM) <- TPM[,1]
TPM_processed <- TPM[,-c(1,2,3)]
boxplot(log2(TPM_processed), las=2, col=col, main="")
title(main="A. iCCA: Unnormalised data",ylab="Log-TPM")

rownames(TPM_tnm) <- TPM_tnm[,1]
TPM_tnm_processed <- TPM_tnm[,-c(1,2,3)]
boxplot(log2(TPM_tnm_processed), las=2, col=col, main="")
title(main="B. iCCA: Normalised data",ylab="Log-FPKM")


## Density plot

# Function to create a density plot comparing raw and filtered data
density_plot <- function(fpkm_data, tpm_data, samplenames, cutoff = 1, ylim = c(0, 0.4)) {
  # Load color palette library (assuming not already loaded)
  library(RColorBrewer)
  
  # Get number of samples
  nsamples <- ncol(fpkm_data)
  
  # Create color palette
  col <- brewer.pal(nsamples, "Paired")
  
  # Set plot layout
  par(mfrow = c(1, 2))
  
  # Raw data processing
  log_fpkm <- log2(fpkm_data + 1)
  # log_fpkm[is.na(log_fpkm)] <- 0
  
  # Raw data plot (Panel A)
  plot(density(log_fpkm[, 1]), col = col[1], lwd = 2, ylim = ylim, las = 2, main = "", xlab = "")
  title(main = "A. Raw data", xlab = "Log-TPM")
  abline(v = cutoff, lty = 3)
  for (i in 2:nsamples) {
    den <- density(log_fpkm[, i])
    lines(den$x, den$y, col = col[i], lwd = 2)
  }
  legend("topright", samplenames, text.col = col, bty = "n")
  
  # Filtered data processing
  log_tpm <- log2(tpm_data + 1)
  log_tpm[is.na(log_tpm)] <- 0
  
  # Filtered data plot (Panel B)
  plot(density(log_tpm[, 1]), col = col[1], lwd = 2, ylim = ylim, las = 2, main = "", xlab = "")
  title(main = "B. Filtered data", xlab = "Log-TPM")
  abline(v = cutoff, lty = 3)
  for (i in 2:nsamples) {
    den <- density(log_tpm[, i])
    lines(den$x, den$y, col = col[i], lwd = 2)
  }
  legend("topright", samplenames, text.col = col, bty = "n")
}

# dge_filtered$counts
density_plot(counts, TPM_processed, samplenames=colnames(FPKM_processed), cutoff = 1, ylim = c(0, 0.4))







library(RColorBrewer)
nsamples <- ncol(FPKM_processed)
col <- brewer.pal(nsamples, "Paired")
par(mfrow=c(1,2))
log_FPKM.cutoff <- 1

log_FPKM = log2(FPKM_processed+1)
log_FPKM[is.na(log_FPKM)] <- 0
plot(density(log_FPKM[,1]), col=col[1], lwd=2, ylim=c(0, 0.4), las=2, main="", xlab="")
title(main="A. Raw data", xlab="Log-cpm")
abline(v=log_FPKM.cutoff, lty=3)
for (i in 2:nsamples){
  den <- density(log_FPKM[,i])
  lines(den$x, den$y, col=col[i], lwd=2)
}
legend("topright", samplenames, text.col=col, bty="n")


log_TPM = log2(TPM_processed+1)
log_TPM[is.na(log_TPM)] <- 0
plot(density(log_TPM[,1]), col=col[1], lwd=2, ylim=c(0, 0.4), las=2, main="", xlab="")
title(main="B. Filtered data", xlab="Log-TPM")
abline(v=log_FPKM.cutoff, lty=3)
for (i in 2:nsamples){
  den <- density(log_TPM[,i])
  lines(den$x, den$y, col=col[i], lwd=2)
}
legend("topright", samplenames, text.col=col, bty="n")


lcpm <- cpm(x, log=TRUE)
plot(density(lcpm[,1]), col=col[1], lwd=2, ylim=c(0,0.26), las=2, main="", xlab="")
title(main="B. Filtered data", xlab="Log-FPKM")
abline(v=lcpm.cutoff, lty=3)
for (i in 2:nsamples){
  den <- density(lcpm[,i])
  lines(den$x, den$y, col=col[i], lwd=2)
}
legend("topright", samplenames, text.col=col, bty="n")














# Assuming gene lengths are stored in dge_tmm$genes$length and are in base pairs,
# convert lengths from base pairs to kilobases
gene_lengths_kb <- dge_tmm$genes$gene_length / 1000

# Now calculate FPKM
# Note: cpm_tmm is a matrix, so we need to divide each column by the gene lengths in kilobases
# Then, because CPM already accounts for per-million scaling, we only divide by gene length here
fpkm_tmm <- sweep(cpm_tmm, 1, gene_lengths_kb, FUN="/")

convert_cpm_to_fpkm <- function(cpm_values, gene_lengths) {
  # 假设 cpm_values 是一个向量，包含每个基因的 CPM 值
  # gene_lengths 是一个向量，包含每个基因的长度（例如，基因的外显子长度）
  
  # 计算每个基因的总测序深度
  total_mapped_reads <- sum(cpm_values)
  
  # 计算每个基因的 FPKM
  fpkm_values <- (cpm_values / total_mapped_reads) * 1e9 / gene_lengths
  
  return(fpkm_values)
}

cpm_to_fpkm <- function(cpm, gene_length) {
  # 检查输入参数
  if (!is.numeric(cpm)) {
    stop("cpm must be numeric")
  }
  if (!is.numeric(gene_length)) {
    stop("gene_length must be numeric")
  }
  
  # 计算 FPKM
  fpkm <- (cpm * 1e6) / gene_length
  
  # 返回 FPKM
  return(fpkm)
}

# rpkmValues = cpm_to_fpkm(cpm_tmm, dge_tmm$genes$gene_length)
# 
# rpkmValues_1 = convert_cpm_to_fpkm(cpm_tmm, dge_tmm$genes$gene_length)


# 转换为TPM
# 接下来，将RPKM/FPKM值转换为TPM。TPM首先对每个基因的RPKM/FPKM进行标准化，然后乘以1e6（每百万）进行缩放。
calculateTPM <- function(rpkmValues) {
  # Replace NA or NaN values with 0. This is one approach; adjustments may be needed based on specific data characteristics.
  rpkmValues[is.na(rpkmValues)] <- 0
  
  # Check for and handle negative values. Negative RPKM values are not expected and should be corrected or investigated.
  if(any(rpkmValues < 0)) {
    stop("Negative values found in RPKM values, which are not valid. Please check your data.")
  }
  
  # Calculate the sum of RPKM values for each sample (column)
  sumRpkm <- colSums(rpkmValues)
  
  # To avoid division by zero, replace zeros in sumRpkm with a very small positive number.
  # This is important for samples where the sum of RPKM values is zero.
  sumRpkm[sumRpkm == 0] <- .Machine$double.eps
  
  # Calculate TPM: Divide each RPKM value by the column sum and multiply by 1e6.
  # This normalization step ensures that the sum of TPM values in each sample equals one million.
  tpmValues <- (rpkmValues / sumRpkm) * 1e6
  
  return(tpmValues)
}


# 应用TPM函数
tpmValues <- calculateTPM(fpkm_tmm)


# If you want to add this as an assay to a SummarizedExperiment object:
# Let's assume you have a SummarizedExperiment object ready
# aml_se <- SummarizedExperiment(assays = List(counts = as.matrix(dge_tmm$counts)))
# # 将FPKM值添加到SummarizedExperiment对象中
# assays(aml_se)$FPKM_TMM <- Matrix::Matrix(fpkm_tmm, sparse=TRUE)

## Organising gene annotations
geneid <- rownames(tpmValues)
genes <- select(Homo.sapiens, keys=geneid, columns=c("SYMBOL", "TXCHROM"), 
                keytype="ENSEMBL")
head(genes)


# To resolve duplicate gene IDs one could combine all chromosome 
# information from the multi-mapped genes.
genes <- genes[!duplicated(genes$ENSEMBL),]

TPM = cbind(genes, tpmValues)

write.csv(TPM, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/RNA_matrix_TPM_1.csv")



assays(dge_filtered)$FPKM_TMM <- Matrix::Matrix(fpkm_tmm, sparse=TRUE)

assay(dge_filtered, "logFPKM_TMM") <- log2(fpkm_tmm + 1)

# 将gene length添加到DGEList对象中
aml_dge$genes$length <- gene_lengths

# 将FPKM值添加到SummarizedExperiment对象中
assay(aml_se, "FPKM_TMM") <- fpkm_tmm


       