library(tidyr)
library(reshape2)
library(ggplot2)
library(ggpubr)
library(dplyr)

# data <- read.csv("/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/code/Integrated-resluts/T_cell_subtype_proportion_wide.csv")
data <- read.csv("/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/Chemo_Immuno/GSVA_pathway_v2/Selected_genes_R_Immuno_v2.csv")
colnames(data)
data_long <- pivot_longer(data, cols = 6:ncol(data), names_to = "Cell_Type", values_to = "Proportion")
data_long$Proportion <- log2(data_long$Proportion + 1)
# 绘制箱线图
median_values <- data_long %>%
  group_by(Cell_Type) %>%
  summarize(median = median(Proportion)) %>%
  arrange(desc(median))  # 按中位数排序

# 将排序应用于 data_long
# data_long$Cell_Type <- ordered(data_long$Cell_Type, levels = median_values$Cell_Type)
data_long$Cell_Type <- ordered(data_long$Cell_Type, levels = c('GADD45B',
                                                               'CDKN1A',
                                                               'SRC',
                                                               'ARPC5L',
                                                               'NFATC4',
                                                               'ERBB2',
                                                               'TUBB4B',
                                                               'TUBB6',
                                                               'TUBA4A',
                                                               'FZD7',
                                                               'DVL3'))

data_long$Cell_Type <- ordered(data_long$Cell_Type, levels = c('TAB3',
                                                               'TRADD',
                                                               'TRAF5',
                                                               'CHUK',
                                                               'SOS1',
                                                               'SOS2',
                                                               'MAP2K4',
                                                               'MAPK8',
                                                               'TIA1',
                                                               'ZMYM2',
                                                               'FGFR1OP2',
                                                               'CPSF6',
                                                               'GAB1'))
# 假设你希望 Response 按照特定顺序绘制
data_long$Response <- factor(data_long$Response, levels = c("The_rest", "R_Immuno"))

ggplot(data_long, aes(x = Cell_Type, y = Proportion, color = Response)) +  # 使用 color 而不是 fill
  geom_boxplot(fill = NA, outlier.shape = NA) +  # 仅绘制边框，不填充，隐藏默认异常值点
  geom_jitter(position = position_jitterdodge(jitter.width = 0.2, dodge.width = 0.6),  # 设置抖动和分组
              alpha = 1) +  # 添加散点，避免重叠
  stat_compare_means(aes(group = Response), method = "t.test", label = "p.signif") +  # 显示显著性 p 值
  labs(title = "Cell Proportion by Response with p-values", x = "Cell Type", y = "Proportion") +
  # scale_color_manual(values = custom_colors) +  # 应用自定义颜色
  scale_color_manual(values = c("The_rest" = "#0E9F87", "R_Immuno" = "#375E97")) +  # 自定义颜色
  theme(axis.text.x = element_text(angle = 45, hjust = 1),  # 旋转 x 轴标签
        legend.title = element_text(face = "bold")) +
  theme(
    axis.text.x = element_text(angle = 18, hjust = 0.6, colour = "black", family = "ArialMT", size = 12),
    axis.title.x = element_text(angle = 0, hjust = 0.5, colour = "black", family = "ArialMT", size = 12),
    axis.text.y = element_text(family = "ArialMT", size = 12, face = "plain"),
    axis.title.y = element_text(family = "ArialMT", size = 12, face = "plain"),
    panel.border = element_blank(), axis.line = element_line(colour = "black", size = 0.8),
    legend.text = element_text(
      face = "plain", family = "ArialMT", colour = "black",
      size = 12
    ),
    legend.title = element_text(
      face = "plain", family = "ArialMT", colour = "black",
      size = 14
    ),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  )






plot_custom_boxplot <- function(data, group_var, response_var, custom_colors) {
  # """
  # Plot a customized boxplot with jitter and custom colors, sorted by median.
  # 
  # Args:
  #     data (str): The long-format matrix.
  #     group_var (str): The variable representing cell type or group to be plotted.
  #     response_var (str): The variable representing response or treatment groups.
  #     custom_colors (list): A named list of colors for different response categories.
  #     output_path (str): The path to save the output boxplot.
  # 
  # Returns:
  #     None. Displays the boxplot and saves it to the specified output path.
  # """
  
  # 读取 CSV 文件并转换为长格式
  data_long <- pivot_longer(data, cols = 4:ncol(data), names_to = group_var, values_to = "Proportion")
  
  # 计算中位数并排序
  median_values <- data_long %>%
    group_by(!!sym(group_var)) %>%
    summarize(median = median(Proportion)) %>%
    arrange(desc(median))  # 按照中位数排序
  
  # 使用 ordered() 函数根据中位数排序
  data_long[[group_var]] <- ordered(data_long[[group_var]], levels = median_values[[group_var]], )
  
  # 绘制箱线图
  ggplot(data_long, aes(x = !!sym(group_var), y = Proportion, color = !!sym(response_var))) +
    geom_boxplot( outlier.shape = 19) +  # 仅描绘边框，不填充
    geom_jitter(width = 0.2, shape = 16, alpha = 1.0) +  # 实心点
    stat_compare_means(aes(group = !!sym(response_var)), method = "t.test", label = "p.signif") +  # 显示 p 值
    labs(title = "Cell Proportion by Response with p-values", x = "Cell Type", y = "Proportion of cell type") +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          legend.title = element_text(face = "bold")) +
    scale_color_manual(values = custom_colors) +  # 自定义颜色
    theme(
      axis.text.x = element_text(angle = 18, hjust = 0.6, colour = "black", family = "ArialMT", size = 12),
      axis.title.x = element_text(angle = 0, hjust = 0.5, colour = "black", family = "ArialMT", size = 12),
      axis.text.y = element_text(family = "ArialMT", size = 12, face = "plain"),
      axis.title.y = element_text(family = "ArialMT", size = 12, face = "plain"),
      panel.border = element_blank(), axis.line = element_line(colour = "black", size = 0.8),
      legend.text = element_text(
        face = "plain", family = "ArialMT", colour = "black",
        size = 12
      ),
      legend.title = element_text(
        face = "plain", family = "ArialMT", colour = "black",
        size = 14
      ),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank()
    )
}

custom_colors <- list("R" = "#0E9F87", "NR" = "#375E97")  # 根据实际数据设置颜色

# 调用函数绘制和保存箱型图
plot_custom_boxplot(data, "Cell_Type", "Response", custom_colors)
