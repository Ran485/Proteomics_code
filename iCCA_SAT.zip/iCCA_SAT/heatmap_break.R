library(pheatmap)
library(RColorBrewer)
# library(ComplexHeatmap)
# library(circlize)


matrix=read.csv("/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/RNA_IPS_features.csv",header=T,row.names = 1)

# matrix = data.frame(t(matrix))
# matrix = matrix[-2,]
# matrix[is.na(matrix)] = 1
# matrix <- log2(matrix+1)
# matrix[matrix == 1] <- NA
matrix <- as.matrix(matrix)
#color for subtype
annotation_col = read.csv ('/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/RNA_anatation_v3.csv',header = T,row.names = 1)
# rownames(annotation_col) = colnames(matrix)
# ann_colors = list(type = c(iCC_N= "#48cae4", eCC_N = "#f48c06", iCC_T = "#0077b6" , eCC_T = "#dc2f02")) ## #0772BC 蓝色
# ann_colors = list(Subtype = c(S_I = "#F94F21",S_II = "#EFC000",S_III = "#00AEBA"))
chending_color = c(colorRampPalette(c("#0772BC", "white"))(30),  ## #184D87  常用#1E90FF ##14417C ## 0772BC ## #395F90黑蓝   ## 淡蓝#1E90FF
                   colorRampPalette(c("white", "red"))(30) ) 

breaks = unique(c(seq(-1.2, 0, length = 31), 0, seq(0, 1.2, length = 31)))


# data1 = data[-c("AMY2B","PEX11B","CDK11A",'CDK11B','EXOG','GNAT3','GNAT1','GNAT2'),]
# log_data = log2(data)

# colnames(annotation_col)
# ann_colors = list(
#   Age = c("#FFFFCB", "#C1E598", "#8BF28B", "#3AC160", "#006837"),
#   Gender = c(Female = "#FCBA83", Male = "#E24F3B"),
#   Response..RECIST. = c(iCCA = "#FB6542", eCCA = "#375E97"),
#   Response = c(smallBD = "#89BCDF", largeBD = "#2080C3",NA_1	 = "#ededed",NA_2	 = "#ededed"),
#   CCP_Class = c(cluster_1= "#1F78B4", cluster_2 = "#33A02C", cluster_3 = "#92CFEA",NA_1	 = "#ededed"),
#   Proteome_Subtype = c(S_I= "#FF800D", S_II = "#0E65AD", S_III = "#FF0027"),
#   Grade = c(GX = "#ffe0e9", G1 = "#ffc2d4",G1_2 = "#ff9ebb", G2 = "#ff7aa2", G2_3 = "#e05780", G3 = "#b9375e"),
#   iccStage = c( IA = "#caf0f8",IB = "#90e0ef", II = "#48cae4", IIIA = "#0096c7", IIIB = "#0077b6", IV = "#023e8a", NA_1 = "#ededed"),
#   eccStage = c( I = "#caf0f8",II = "#90e0ef", IIIA = "#48cae4", IIIB = "#0096c7", IIIC = "#0077b6", IVB = "#023e8a", NA_1 = "#ededed"),
#   Lymphovascular_invasion = c(No	= "#fca311", Yes	 = "#14213d", Unknown	 = "#EDEDED"),
#   Perineural_invasion = c(No	= "#fbd87f", Yes	 = "#c62c43", Unknown	 = "#EDEDED"),
#   Presence_of_fluke_infection = c(No	 = "#EDEDED", Yes	 = "#000000"),
#   Type_2_diabetes = c(No	 = "#EDEDED", Yes	 = "#14213d"),
#   Choledocholithiasis = c(No	= "#020202", Yes	= "#72D672", Unknown	= "#EDEDED"),
#   Cholecystolithiasis = c(No	= "#020202", Yes	= "#72D672", Unknown	= "#EDEDED"),
#   Cholelithiasis_1 = c(No	 = "#EDEDED", Yes	 = "#f5cb5c"),
#   Hypertension = c(No	 = "#EDEDED", Yes	 = "#086375"),
#   CA199 = c(Normal	 = "#ffa5ab", Elevated	 = "#bc4877", NA_1	 = "#ededed"),
#   Tbil = c(Normal	 = "#1282a2", Elevated	 = "#034078", NA_1	 = "#ededed"),
#   ALT = c(Below	 = "#eff48e",Normal	 = "#d2e603", Elevated	 = "#3e978b", NA_1	 = "#ededed"),
#   GGT = c(Normal	 = "#68adff", Elevated	 = "#2b69c9", NA_1	 = "#ededed"),
#   HBV = c(Ever	 = "#9ac9d2", Never	 = "#376770", NA_1	 = "#ededed"),
#   PT = c(Below	 = "#e1f48f",Normal	 = "#f9d073", Elevated	 = "#e5643c", NA_1	 = "#ededed")
# )

pheatmap(matrix, scale = "row",
         cluster_rows= 0,cluster_cols=0,
         clustering_distance_cols = "correlation", fill = T, breaks=breaks,
         clustering_distance_rows = "correlation",border_color ="gray", na_col = "#EDEEEF",
         col=chending_color,show_rownames=T,show_colnames=F,display_numbers=F,
         width = 4.85,height = 5, fontsize_number=18, number_color="black",number_format="%.2f",
         annotation_col = annotation_col) #, annotation_colors = col_list) #, annotation_row = annotation_row)


## Call ComplexHeatmap Fuction
mat_scaled <- t(scale(t(matrix)))  # 转置后标准化再转回
# 处理可能的NaN值（当某行标准差为0时出现）
mat_scaled[is.nan(mat_scaled)] <- 0

# 3. 设置颜色映射范围
min_val <- -2   # 最小值
max_val <- 2    # 最大值

# 4. 创建颜色映射函数
chending_color <- colorRamp2(
  c(min_val, 0, max_val),  # 断点：最小值、0、最大值
  c("#0772BC", "white", "red") # 对应颜色
)

# 5. 可选：将数据限制在[min_val, max_val]范围内
mat_scaled[mat_scaled < min_val] <- min_val
mat_scaled[mat_scaled > max_val] <- max_val

# 6. 绘制热图
Heatmap(mat_scaled,
        name = "scaled",
        cluster_rows = FALSE,
        cluster_columns = FALSE,
        col = chending_color,
        heatmap_legend_param = list(
          direction = "horizontal",
          legend_width = unit(6, "cm"),
          nrow = 1,
          title_position = "topcenter",
          at = c(min_val, 0, max_val)  # 明确显示关键刻度
        ),
        show_row_names = TRUE,
        show_column_names = FALSE,
        top_annotation = HeatmapAnnotation(df = annotation_col),
        width = unit(4.85, "inch"),
        height = unit(5, "inch")
)

n=t(scale(t(matrix))) # 'scale'可以对log-ratio数值进行归一化
n[n>2]= 2
n[0<n & n<2]= 1
n[n<-2]= -2
n[-2< n & n< 0]= -1
n[1:4,1:4]

#  #0672BC(蓝色)
# #3090D1(淡蓝色)


col_list = list(
  Cluster = c('Cluster_1' = '#1F78B4', 'Cluster_2' = '#B2DF8A', 'Cluster_3' = '#33A02C',
              'Cluster_4' = '#FB9A99', 'Cluster_5' = '#E31A1C', 'Cluster_6' = '#FDBF6F'
              # 'Cluster_7' = '#FF7F00', 'Cluster_8' = '#6A3D9A'
  )
)

ann_colors = list(
  Age = c("#FFFFCB", "#C1E598", "#8BF28B", "#3AC160", "#006837"),
  Gender = c(Female = "#FCBA83", Male = "#E24F3B"),
  Pathology = c(iCCA = "#FFC51A", eCCA = "#a767ff"),
  iCCA_Pathology = c(smallBD = "#89BCDF", largeBD = "#2080C3",NA_1	 = "#ededed",NA_2	 = "#ededed"),
  CCP_Class = c(cluster_1= "#1F78B4", cluster_2 = "#33A02C", cluster_3 = "#92CFEA",NA_1	 = "#ededed"),
  Proteome_Subtype = c(S_I= "#FF800D", S_II = "#0E65AD", S_III = "#FF0027"),
  Grade = c(GX = "#ffe0e9", G1 = "#ffc2d4",G1_2 = "#ff9ebb", G2 = "#ff7aa2", G2_3 = "#e05780", G3 = "#b9375e"),
  iccStage = c( IA = "#caf0f8",IB = "#90e0ef", II = "#48cae4", IIIA = "#0096c7", IIIB = "#0077b6", IV = "#023e8a", NA_1 = "#ededed"),
  eccStage = c( I = "#caf0f8",II = "#90e0ef", IIIA = "#48cae4", IIIB = "#0096c7", IIIC = "#0077b6", IVB = "#023e8a", NA_1 = "#ededed"),
  Lymphovascular_invasion = c(No	= "#fca311", Yes	 = "#14213d", Unknown	 = "#EDEDED"),
  Perineural_invasion = c(No	= "#fbd87f", Yes	 = "#c62c43", Unknown	 = "#EDEDED"),
  Presence_of_fluke_infection = c(No	 = "#EDEDED", Yes	 = "#000000"),
  Type_2_diabetes = c(No	 = "#EDEDED", Yes	 = "#14213d"),
  Choledocholithiasis = c(No	= "#020202", Yes	= "#72D672", Unknown	= "#EDEDED"),
  Cholecystolithiasis = c(No	= "#020202", Yes	= "#72D672", Unknown	= "#EDEDED"),
  Cholelithiasis_1 = c(No	 = "#EDEDED", Yes	 = "#f5cb5c"),
  Hypertension = c(No	 = "#EDEDED", Yes	 = "#086375"),
  CA199 = c(Normal	 = "#ffa5ab", Elevated	 = "#bc4877", NA_1	 = "#ededed"),
  Tbil = c(Normal	 = "#1282a2", Elevated	 = "#034078", NA_1	 = "#ededed"),
  ALT = c(Below	 = "#eff48e",Normal	 = "#d2e603", Elevated	 = "#3e978b", NA_1	 = "#ededed"),
  GGT = c(Normal	 = "#68adff", Elevated	 = "#2b69c9", NA_1	 = "#ededed"),
  HBV = c(Ever	 = "#9ac9d2", Never	 = "#376770", NA_1	 = "#ededed"),
  PT = c(Below	 = "#e1f48f",Normal	 = "#f9d073", Elevated	 = "#e5643c", NA_1	 = "#ededed")
)
