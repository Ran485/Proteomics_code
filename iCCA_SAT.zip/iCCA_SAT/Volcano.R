#=========================================================================
# Panel=Fig7 - Scatter plot for Clinical and xCell signature overall survival
#=========================================================================
library(ggplot2)
library(ggrepel)
library(tools)


capitalize_first_letter <- function(x) {
  # 将每个单词的首字母大写
  sapply(strsplit(x, " "), function(words) {
    paste(toupper(substring(words, 1, 1)), substring(words, 2), sep = "", collapse = " ")
  })
}

genes <- read.csv("//Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/Chemo_Immuno/GSVA_pathway_v2/KEGG/R_Immuno/KEGG/ssGSEA_results_pvalue.csv", header = TRUE)
colnames(genes)
genes$Pathway <- tools::toTitleCase(tolower(genes$Pathway))

genes$Significant <- ifelse(genes$P.Value < 0.15 & genes$logFC > 0.15 , "Up-regulated pathway",
                            ifelse(genes$P.Value < 0.15 & genes$logFC < -0.15 , "Down-regulated pathway","Not Sig"))
genes$size = ifelse(genes$Significant == "Up-regulated pathway" | genes$Significant == "Down-regulated pathway" , abs(genes$logFC), 0.2)

ggplot(genes, aes(x = logFC , y = -log10(P.Value), size = size)) +
  geom_point(aes(color = Significant)) +
  scale_size_continuous(range = c(2,4))+
  scale_color_manual(values = c("#375E97","gray","#FB6542")) + # ("gray", "#7AA9CE") c( "#EA686B","#7AA9CE","gray")) c("#515151", "red"))
  theme_bw(base_size = 12) + theme(legend.position = "right") +
  geom_text_repel(
    data = subset(genes, Display == "display"),
    aes(label = Pathway),
    size = 5,
    box.padding = unit(0.35, "lines"),
    point.padding = unit(0.3, "lines")
  )+
  theme(panel.border = element_blank(), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+
  ggtitle("Pathway Enrichments between R_Immuno/The_rest groups ")+
  theme(axis.text.x=element_text(angle=0,hjust = 0.6,colour="black",family="Arial",size=16), #设置x轴刻度标签的字体显示倾斜角度为15度，并向下调整1(hjust = 1)，字体簇为Times大小为20
        axis.title.x=element_text(angle=0,hjust = 0.5,colour="black",family="Arial",size=16),
        axis.text.y=element_text(family="Arial",size=16,face="plain"), #设置y轴刻度标签的字体簇，字体大小，字体样式为plain
        axis.title.y=element_text(family="Arial",size = 20,face="plain"), #设置y轴标题的字体属性
        panel.border = element_blank(),axis.line = element_line(colour = "black",size=0.8), #去除默认填充的灰色，并将x=0轴和y=0轴加粗显示(size=1)
        legend.text=element_text(face="plain", family="Arial", colour="black",  #设置图例的子标题的字体属性
                                 size=12),
        legend.title=element_text(face="plain", family="Arial", colour="black", #设置图例的总标题的字体属性
                                  size=12),
        panel.grid.major = element_blank(),   #不显示网格线
        panel.grid.minor = element_blank())+
  geom_hline(yintercept = 1.301,color = 'gray', linetype="dashed")+
  geom_vline(xintercept = -0.2,color = 'gray', linetype="dashed") +
  geom_vline(xintercept = 0.2,color = 'gray', linetype="dashed") 
# scale_x_continuous(limits = c(-0.25, 0.3))+
# scale_y_continuous(breaks=seq(0, 4, 1))
# panel.border = element_rect(colour = "black", fill=NA, size=1)