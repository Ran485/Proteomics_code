# package install

# options("repos"= c(CRAN="https://mirrors.tuna.tsinghua.edu.cn/CRAN/"))
# options(BioC_mirror="http://mirrors.tuna.tsinghua.edu.cn/bioconductor/")
# if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
# 
# depens<-c('tibble', 'survival', 'survminer', 'sva', 'limma', "DESeq2","devtools",
#           'limSolve', 'GSVA', 'e1071', 'preprocessCore', 'ggplot2', "biomaRt",
#           'ggpubr', "devtools", "tidyHeatmap", "caret", "glmnet", "ppcor", "timeROC","pracma")
# for(i in 1:length(depens)){
#   depen<-depens[i]
#   if (!requireNamespace(depen, quietly = TRUE))
#     BiocManager::install(depen,update = FALSE)
# }
# 
# if (!requireNamespace("IOBR", quietly = TRUE))
#   devtools::install_github("IOBR/IOBR")


library(IOBR)
library(tidyr)
library(limma)

# TME 分析上下文可用的方法
tme_deconvolution_methods

# 可用的特征估计方法
signature_score_calculation_methods

# 标志基因收集
# reference of collected signature
signature_collection_citation[!duplicated(signature_collection_citation$Journal),]
sig_group[1:3]

# load data
expr_matrix <- read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/edgeR/cleaned_data/RNA_matrix_TPM_tnm.csv",row.names = 1)
group <- read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/RNA_cibersort_ana.csv")

# data preprocess
boxplot(expr_matrix,outline=F, notch=F , las=2)
# 均数不一致需标准化 ---------------------------------------------------------------
DEG_expr=normalizeBetweenArrays(DEG_expr)
boxplot(DEG_expr,outline=FALSE, notch=F , las=2)

# expr_matrix  <- log2(expr_matrix + 1)
# TME 反卷积分析
im_cibersort<-deconvo_tme(eset = expr_matrix, method = "cibersort", arrays = TRUE, perm = 1000)
# head(cibersort)
# res<-cell_bar_plot(input = cibersort[1:12,], pattern = "CIBERSORT", title = "CIBERSORT Cell Fraction")

im_epic<-deconvo_tme(eset = expr_matrix, method = "epic", arrays = TRUE)
im_xcell<-deconvo_tme(eset = expr_matrix, method = "xcell", arrays = TRUE)
im_mcp<-deconvo_tme(eset = expr_matrix, method = "mcpcounter")
im_estimate<-deconvo_tme(eset = expr_matrix, method = "estimate")
im_timer<-deconvo_tme(eset = expr_matrix, method = "timer", group_list = rep("stad",dim(expr_matrix)[2]))
im_quantiseq<-deconvo_tme(eset = expr_matrix, tumor = TRUE, arrays = TRUE, scale_mrna = TRUE, method = "quantiseq")
im_ips<-deconvo_tme(eset = expr_matrix, method = "ips", plot= FALSE)


# 合并8种免疫浸润方法分析的结果
tme_combine <- im_mcp %>% 
  inner_join(im_epic, by="ID") %>% 
  inner_join(im_xcell, by="ID") %>% 
  inner_join(im_cibersort, by="ID") %>% 
  inner_join(im_ips, by= "ID") %>% 
  inner_join(im_quantiseq, by="ID") %>% 
  inner_join(im_estimate, by= "ID") %>% 
  inner_join(im_timer, by= "ID")


## 基于ssGSEA计算免疫浸润分数
load(file = "/Volumes/Samsung_T5/东方肝胆外科合作项目/source/ssGSEA28.Rdata")
im_ssgsea <- calculate_sig_score(eset = expr_matrix,
                                 signature = cellMarker, # 这个28种细胞的文件需要自己准备
                                 method = "ssgsea" # 选这个就好了
)


tme_combine <- tme_combine %>% 
  inner_join(im_ssgsea, by = "ID")


write.csv(tme_combine, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/TiME/tme_combine_tpm_tnm_qn.csv")
## reference

# - https://mp.weixin.qq.com/s/s2fVEfr3HENrYHNPT2xMxQ
# - https://cloud.tencent.com/developer/article/2319581
# - https://www.biowolf.cn/m/view.php?aid=432. 细胞浸润不同工具包的比较
# - https://zhuanlan.zhihu.com/p/659583002 免疫浸润结果分子分型一致性聚类
# - https://mp.weixin.qq.com/s/YcUVElp0BEj5TxEqfSEkIQ 免疫浸润结果可视化
# - https://cloud.tencent.com/developer/article/1966505?areaId=106001 免疫浸润结果可视化
# - https://cloud.tencent.com/developer/article/2327940?areaId=106001

