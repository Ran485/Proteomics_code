rm(list = ls())
library(maftools)
options(stringsAsFactors = F)

##  ===================== 定义输出目录 =====================
OUTPUT_DIR <- "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/Mutation_results"  # 替换为您希望的输出路径

# 检查目录是否存在，如果不存在则创建
if (!dir.exists(OUTPUT_DIR)) {
  dir.create(OUTPUT_DIR, recursive = TRUE)
  message(paste("创建目录:", OUTPUT_DIR))
} else {
  message(paste("目录已存在:", OUTPUT_DIR))
}

## annovar
# annovar.laml <- annovarToMaf(annovar = "/Users/ranpeng/Desktop/iCCA_SAT/annotation/annovar/annovar_merge.vcf", 
#                              refBuild = 'hg38',
#                              tsbCol = 'Tumor_Sample_Barcode', 
#                              table = 'refGene',
#                              MAFobj = T)
# 
# ## 统计一下case1_biorep_A_techrep样本的突变类型
# table(annovar.laml@data[annovar.laml@data$Tumor_Sample_Barcode=='T240194',]$Func.knownGene)
# ## exonic intergenic 
# ##   172          1
# 
# table(annovar.laml@data[annovar.laml@data$Tumor_Sample_Barcode=='T240194',]$Variant_Type)
# ## DEL INS SNP 
# ##  5   0 168
# 
# table(annovar.laml@data[annovar.laml@data$Tumor_Sample_Barcode=='T240194',]$Variant_Classification)

## ============ Load Maf and Clincial data ================
# 指定MAF和临床数据的表格
iCCA_maf = "/Users/ranpeng/Desktop/iCCA_SAT/annotation/funcotator/funcotator_merge.maf"
# clinicalData = "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/WES_metadata.csv"
clinicalData = "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/Fig1_clinical_feature_anatation_20241116.csv"

clincial_metadata = read.csv(clinicalData)

laml = read.maf(maf = iCCA_maf, clinicalData = clinicalData)

## ============ Summry maf information ================
# Shows sample summry.
getSampleSummary(laml)
# Shows gene summary.
getGeneSummary(laml)
# shows clinical data associated with samples
getClinicalData(laml)
# Shows all fields in MAF
getFields(laml)
# Writes maf summary to an output file with basename laml.
write.mafSummary(maf = laml, basename = 'laml')

## ============ Visualization ================

# 7.1 Plotting MAF summary.
plotmafSummary(maf = laml, rmOutlier = TRUE, addStat = 'median', dashboard = TRUE, titvRaw = FALSE)

# 7.2.1 Drawing oncoplots
#oncoplot for top ten mutated genes.
oncoplot(maf = laml, top = 10000, writeMatrix = TRUE)


pdf('/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/figs/oncoplot_clin_all_noamp.pdf',width=8,height=12)
oncoplot(maf = laml, 
         genes = c('TP53','BRCA1','KMT2D','ARID2','MET','RB1','TSC2','ARID1A','KEAP1','FGFR4','BRCA2','NOTCH1',
                   'SPTA1','KRAS','PIK3CA','SMAD4','NFE2L2','KDM6A','PBRM1','FGFR3','JAK3','MPL','ZNF536','TERT',
                   'IDH1','IDH2','FGFR2','FBXW7','EGFR','FGFR1','CDKN2A'),
         showTumorSampleBarcodes=F,
         # colors = vc_cols,
         keepGeneOrder = TRUE,
         writeMatrix = TRUE,
         sortByAnnotation=TRUE, borderCol = "white", bgCol = "#F4F4F4", draw_titv = T,
         clinicalFeatures = c('Response','Response (RECIST)','Gender'))
dev.off()

## ============ The TMB  ================
# 计算每个病人的 TMB
tmb_data <- tmb(maf = laml)
# 合并 TMB 数据与临床数据
# 按样本编号匹配（例如 Tumor_Sample_Barcode）
merged_data <- merge(clincial_metadata, tmb_data, by = "Tumor_Sample_Barcode", all.x = TRUE)
write.csv(merged_data, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/clincial_metadata_TMB.csv")

## ============ Synonymous 和 Non-Synonymous 突变个数  ================
# 定义统计突变的函数
count_mutations <- function(maf) {
  # Synonymous 突变统计
  synonymous_counts <- maf@data[Variant_Classification == "Nonsense_Mutation", .N, by = Tumor_Sample_Barcode]
  synonymous_counts[, mutation_type := "aSynonymous_counts"]
  
  # Non-Synonymous 突变统计
  non_synonymous_counts <- maf@data[Variant_Classification %in% c(
    "Missense_Mutation", "Nonstop_Mutation",
    "Splice_Site", "Frame_Shift_Del", "Frame_Shift_Ins",
    "In_Frame_Del", "In_Frame_Ins"
  ), .N, by = Tumor_Sample_Barcode]
  non_synonymous_counts[, mutation_type := "Non_Synonymous_counts"]
  
  # 合并 Synonymous 和 Non-Synonymous 的统计
  mutation_counts <- rbind(
    synonymous_counts[, .(Tumor_Sample_Barcode, mutation_type, count = N)],
    non_synonymous_counts[, .(Tumor_Sample_Barcode, mutation_type, count = N)]
  )
  
  # 按照输出格式重命名列
  colnames(mutation_counts) <- c("index", "mutation_type", "count")
  
  # 返回结果
  return(mutation_counts)
}

# 调用函数统计突变
mutation_summary <- count_mutations(laml)

# 导出结果为文件
write.csv(mutation_summary, file = "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/Non_Synonymous_mutation_summary.csv", row.names = FALSE)

# 7.3 Transition and Transversions.
laml.titv = titv(maf = laml, plot = FALSE, useSyn = TRUE)
#plot titv summary
plotTiTv(res = laml.titv)

# 9.1 Somatic Interactions
#exclusive/co-occurance event analysis on top 10 mutated genes. 
somaticInteractions(maf = laml, top = 25, pvalue = c(0.05, 0.1))

# 9.2 Detecting cancer driver genes based on positional clustering
laml.sig = oncodrive(maf = laml, AACol = 'Protein_Change', minMut = 5, pvalMethod = 'zscore')

head(laml.sig)

plotOncodrive(res = laml.sig, fdrCutOff = 0.5, useFraction = TRUE, labelSize = 0.2)


## ============ Plot oncogenic pathways ================ 
pws = pathways(maf = laml, plotType = 'treemap')
# 查看 pws 的结构
str(pws)


# 提取通路主要信息
pathway_info <- as.data.frame(pws)

# 查看通路信息
print(pathway_info)

# 提取 'genes' 属性
pathway_genes_list <- attr(pws, "genes")

# 将基因列表转换为数据框
pathway_genes_df <- bind_rows(
  lapply(names(pathway_genes_list), function(pathway) {
    data.frame(Pathway = pathway, Gene = pathway_genes_list[[pathway]], stringsAsFactors = FALSE)
  })
)

# 查看通路基因数据框的前几行
head(pathway_genes_df)
# 导出通路信息和基因列表为CSV文件
write.csv(pathway_info, file.path(OUTPUT_DIR, "pathway_info.csv"))
write.csv(pathway_genes_df, file.path(OUTPUT_DIR, "pathway_genes.csv"))

## ===========   3. 提取病人的突变信息并导出 ================
# 提取 MAF 数据框
maf_df <- as.data.frame(laml@data)

# 查看 MAF 数据框的结构
str(maf_df)

# 根据实际的列名选择样本名和基因名
# 通常样本名列为 'Tumor_Sample_Barcode'，基因名列为 'Hugo_Symbol'
mutation_table <- maf_df %>%
  select(Tumor_Sample_Barcode, Hugo_Symbol) %>%
  distinct()

# 将数据转换为宽格式矩阵，每行代表一个病人，每列代表一个基因，标记突变与否
mutation_matrix <- mutation_table %>%
  mutate(Mutated = 1) %>%
  pivot_wider(names_from = Hugo_Symbol, values_from = Mutated, values_fill = 0)

# 查看突变矩阵的前几行
head(mutation_matrix)

# 导出突变矩阵为CSV文件
write.csv(mutation_matrix, file.path(OUTPUT_DIR, "patient_mutation_matrix.csv"))

## ===========   4. 结合通路信息与病人突变数据  ================
# 提取病人ID
patient_ids <- mutation_matrix$Tumor_Sample_Barcode

# 获取所有通路及其基因列表
pathway_list <- pathway_genes_df %>%
  group_by(Pathway) %>%
  summarise(Genes = list(Gene), .groups = 'drop')

# 初始化一个数据框，用于存储每条通路每个病人的突变情况
pathway_mutation_matrix <- data.frame(Tumor_Sample_Barcode = patient_ids, stringsAsFactors = FALSE)

# 遍历每条通路，计算每个病人在该通路中是否有突变
for(i in 1:nrow(pathway_list)){
  pathway_name <- pathway_list$Pathway[i]
  genes <- pathway_list$Genes[[i]]
  
  # 检查哪些病人有突变的基因在该通路中
  # 注意：检查的基因是否在mutation_matrix的列中
  genes_present <- genes[genes %in% colnames(mutation_matrix)]
  
  if(length(genes_present) == 0){
    # 如果通路中的基因没有在mutation_matrix中找到，全部标记为0
    pathway_mutation_matrix[[pathway_name]] <- 0
  } else {
    # 计算每个病人在该通路中的突变状态
    pathway_mutations <- mutation_matrix %>%
      select(all_of(genes_present)) %>%
      apply(1, function(x) ifelse(any(x == 1), 1, 0))
    
    # 添加到通路突变矩阵中
    pathway_mutation_matrix[[pathway_name]] <- pathway_mutations
  }
}

# 查看通路突变矩阵的前几行
head(pathway_mutation_matrix)

# 导出通路突变矩阵为CSV文件
write.csv(pathway_mutation_matrix, file.path(OUTPUT_DIR, "pathway_mutation_matrix.csv"))

## ===========   5. 导出绘图所需的额外数据（可选）  ================

# 计算每条通路中突变的病人数
pathway_mutation_freq <- pathway_mutation_matrix %>%
  select(-Tumor_Sample_Barcode) %>%
  summarise_all(sum) %>%
  pivot_longer(cols = everything(), names_to = "Pathway", values_to = "Mutation_Count")

# 计算突变频率（百分比）
total_samples <- nrow(pathway_mutation_matrix)
pathway_mutation_freq <- pathway_mutation_freq %>%
  mutate(Mutation_Frequency_Percent = (Mutation_Count / total_samples) * 100)

# 查看突变频率
print(pathway_mutation_freq)

# 导出突变频率为CSV文件
write.csv(pathway_mutation_freq, file.path(OUTPUT_DIR, "pathway_mutation_frequency.csv"))

## ===========   6. 导出绘图本身为图像文件）  ================

pdf(file.path(OUTPUT_DIR, "pathways_treemap.pdf"), width = 12, height = 8)
plotPathways(
  maf = laml,
  pathlist = pws,
  showTumorSampleBarcodes = TRUE,  # 根据需要调整参数
  sampleOrder = clincial_metadata$Tumor_Sample_Barcode
)
dev.off()

plotPathways(maf = laml, pathlist = pws)

plotPathways(maf = laml, pathlist = pws, showTumorSampleBarcodes = T, 
             sampleOrder = clincial_metadata$Tumor_Sample_Barcode)

# 查看每条通路及其对应基因
pathways_info <- pws$Pathway
print(pathways_info)


