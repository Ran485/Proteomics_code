### 清空数据
rm(list = ls())
# options(digits = 10)
### 载入所需要的包
library(survival)
library(survminer)
library(dplyr)
library(ggplot2)
library(readxl)
library(ggsurvfit)
### 数据加载
# data = read_excel('/Volumes/Samsung_T5/downloads/Integrated_multiomics_analysis_CCA/data/response/response_R1C3_ARID1A/ARID1A_index.xlsx',sheet=1)
# data = read.csv("/Volumes/Samsung_T5/downloads/Integrated_multiomics_analysis_CCA/data/response/FGFR_alteration_OS.csv")
data = read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/Fig1_clinical_feature_oncogene_mutaion_OS_20241117.csv")
colnames(data)
# data$Medication.efficacy <- factor(data$Medication.efficacy,levels = c(0,1),labels = c("NDB","DCB"))

surv <- function(info_data){
  sfit <- survfit(Surv(OS, Status) ~ Response , data = data)
  splots <- list()
  splots[[1]] = ggsurvplot(sfit, conf.int=F, pval=TRUE,risk.table = TRUE, risk.table.col = "strata",
                           # xlim = c(0,60),
                           palette = c("#FF9E29", "#1E92D3", "#F94F21", "#916CA0", "#599BAD", "#DBD289", "#FB9A99", "#A4D873", "#99CAE0"))
  res<-arrange_ggsurvplots(splots, print = F,ncol = 1, nrow = 1, risk.table.height = 0.25)
  res
  ggsave(res, file = "/Users/ranpeng/Library/Mobile Documents/com~apple~CloudDocs/Desktop/免疫治疗血浆样本/Figs/fig1/CV_protein_abundance_scatter.pdf", width = 8, height = 5.5)
}

surv
surv(data)

#=========================================================================
# Panel=Fig1C - Cox Proportional-Hazards Model for DCB and NCB
#=========================================================================
# data = data[data$X6q14.3_Deletion_N!='Amp',]
exprSet = data
### 对需要做生存分析的样本分组，把连续变量变成分类变量，这里选择测试的基因是GATA3,这里使用中位数
group = ifelse(exprSet$total_perMB >= quantile(exprSet$total_perMB, 0.44),'zHigh','Low')
# group = exprSet$BAP1
# exprSet = as.data.frame(data)
colnames(exprSet)

# -------- PFS ----------
## 首先利用survfit函数拟合得到生存对象 sfit,
sfit <- survfit(Surv(OS, Status) ~ group, data=exprSet)
p = ggsurvplot(sfit, conf.int=F, pval=TRUE,risk.table = TRUE, risk.table.col = "strata",
               # xlim = c(0,60),
               palette = c("#375E97","#FB6542","#0E9F87","#1E92D3","#FF9E29","#F94F21", "#1E92D3", "#F94F21", "#916CA0", "#599BAD", "#DBD289", "#FB9A99", "#A4D873", "#99CAE0"))
p

sfit <- survfit(Surv(PFS, Progress) ~ group, data=exprSet)
p = ggsurvplot(sfit, conf.int=F, pval=TRUE,risk.table = TRUE, risk.table.col = "strata",
               # xlim = c(0,60),
               palette = c("#375E97","#FB6542","#0E9F87","#1E92D3","#FF9E29","#F94F21", "#1E92D3", "#F94F21", "#916CA0", "#599BAD", "#DBD289", "#FB9A99", "#A4D873", "#99CAE0"))
p


# -------- OS ----------
## 首先利用survfit函数拟合得到生存对象 sfit,
sfit <- survfit(Surv(OS, Status) ~ group, data=exprSet)
p = ggsurvplot(sfit, conf.int=F, pval=TRUE,risk.table = TRUE, risk.table.col = "strata",
               # xlim = c(0,60),
               palette = c("#3C5588","#0E9F87","#1E92D3","#FF9E29","#F94F21", "#1E92D3", "#F94F21", "#916CA0", "#599BAD", "#DBD289", "#FB9A99", "#A4D873", "#99CAE0"))
p

# "#3C5588","#0E9F87","#1E92D3","#FF9E29","#F94F21",
# "#0E9F87", "#3C5588"
# 添加COX回归hazard ratio值等相关信息**
res_cox<-coxph(Surv(OS, Status) ~ group, data=exprSet)
## 获取样本注释信息
sample_count = data.frame(table(exprSet$Medication.efficacy))
surv_median_os = data.frame(surv_median(sfit))
surv_median_os = cbind(sample_count,surv_median_os)
p$plot = p$plot + 
  ## 添加HR info
  ggplot2::annotate("text",x = 4, y = 0.12,size = 5,color='gray',family = "Arial",fontface = "plain",label = paste("HR :",round(summary(res_cox)$conf.int[1],2), "(","95%CI:",round(summary(res_cox)$conf.int[3],2),"-",round(summary(res_cox)$conf.int[4],2),")",sep = "")) +
  # ggplot2::annotate("text",x = 10, y = 0.10,size = 5,color='gray',family = "Arial",fontface = "plain",label = paste("(","95%CI:",round(summary(res_cox)$conf.int[3],2),"-",round(summary(res_cox)$conf.int[4],2),")",sep = ""))+
  ggplot2::annotate("text",x = 4, y = 0.05, size = 5,color='gray',family = "Arial",fontface = "plain",label = paste("logrank-test pval:",round(summary(res_cox)$coef[5],4))) +
  ## 添加中位生存 info
  ggplot2::annotate("text",x = 40, y = 0.9,size = 4,color='#AB1420', family = "Arial", fontface = "bold",label = paste("--- ",surv_median_os[1,1],", n = ",round(surv_median_os[1,2],3),", ","MST = ",round(surv_median_os[1,4],3)," months",sep = ""))+
  ggplot2::annotate("text",x = 40, y = 0.8,size = 4,color='#0070A6', family = "Arial", fontface = "bold",label = paste("--- ",surv_median_os[2,1],", n = ",round(surv_median_os[2,2],3),", ","MST = ",round(surv_median_os[2,4],1)," months",sep = ""))

p



#=========================================================================
# Panel=Fig1C - Cox Proportional-Hazards Model for DCB and NCB of III and IV
#=========================================================================
data1 = data[data$Tumor.stage != 4,]
exprSet = data1
### 对需要做生存分析的样本分组，把连续变量变成分类变量，这里选择测试的基因是GATA3,这里使用中位数
# group = ifelse(exprSet$SH3BGRL2 >= median(exprSet$SH3BGRL2),'zHigh','Low')
# group = exprSet$BAP1
# exprSet = as.data.frame(data)
colnames(exprSet)
## 首先利用survfit函数拟合得到生存对象 sfit,
sfit <- survfit(Surv(Overall.survival.month., Survival.1.dead.0.alive.) ~ Medication.efficacy, data=exprSet)
p = ggsurvplot(sfit, conf.int=F, pval=TRUE,risk.table = TRUE, risk.table.col = "strata",
               # xlim = c(0,60),
               palette = c("#3C5588","#0E9F87","#1E92D3","#FF9E29","#F94F21", "#1E92D3", "#F94F21", "#916CA0", "#599BAD", "#DBD289", "#FB9A99", "#A4D873", "#99CAE0"))
p
# "#3C5588","#0E9F87","#1E92D3","#FF9E29","#F94F21",
# "#0E9F87", "#3C5588"
# 添加COX回归hazard ratio值等相关信息**
res_cox<-coxph(Surv(Overall.survival.month., Survival.1.dead.0.alive.) ~Medication.efficacy, data=exprSet)
## 获取样本注释信息
sample_count = data.frame(table(exprSet$Medication.efficacy))
surv_median_os = data.frame(surv_median(sfit))
surv_median_os = cbind(sample_count,surv_median_os)
p$plot = p$plot + 
  ## 添加HR info
  ggplot2::annotate("text",x = 4, y = 0.12,size = 5,color='gray',family = "Arial",fontface = "plain",label = paste("HR :",round(summary(res_cox)$conf.int[1],2), "(","95%CI:",round(summary(res_cox)$conf.int[3],2),"-",round(summary(res_cox)$conf.int[4],2),")",sep = "")) +
  # ggplot2::annotate("text",x = 10, y = 0.10,size = 5,color='gray',family = "Arial",fontface = "plain",label = paste("(","95%CI:",round(summary(res_cox)$conf.int[3],2),"-",round(summary(res_cox)$conf.int[4],2),")",sep = ""))+
  ggplot2::annotate("text",x = 4, y = 0.05, size = 5,color='gray',family = "Arial",fontface = "plain",label = paste("logrank-test pval:",round(summary(res_cox)$coef[5],4))) +
  ## 添加中位生存 info
  ggplot2::annotate("text",x = 40, y = 0.9,size = 4,color='#AB1420', family = "Arial", fontface = "bold",label = paste("--- ",surv_median_os[1,1],", n = ",round(surv_median_os[1,2],3),", ","MST = ",round(surv_median_os[1,4],3)," months",sep = ""))+
  ggplot2::annotate("text",x = 40, y = 0.8,size = 4,color='#0070A6', family = "Arial", fontface = "bold",label = paste("--- ",surv_median_os[2,1],", n = ",round(surv_median_os[2,2],3),", ","MST = ",round(surv_median_os[2,4],1)," months",sep = ""))

p

