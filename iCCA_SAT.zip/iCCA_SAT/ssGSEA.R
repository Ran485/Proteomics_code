# source("https://bioconductor.org/biocLite.R")
# biocLite("GSVA")
library(GSVA)
# library(piano)
library(limma)
library(BBmisc)
library(ComplexHeatmap)
library(circlize)
# library(Hmisc)
library(GSEABase)
library(EGSEA)
library(GSEABase)
library(dplyr)

## -----------------------load gmt file -----------------------------------------

KEGG <- getGmt("/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/code/genesets/c2.cp.kegg_medicus.v2025.1.Hs.symbols.gmt")
Hall_mark <- getGmt("/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/code/genesets/h.all.v2025.1.Hs.symbols.gmt")
Reactome <- getGmt("/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/code/genesets/c2.cp.reactome.v2025.1.Hs.symbols.gmt")
GO_BP <- getGmt("/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/code/genesets/c5.go.bp.v2025.1.Hs.symbols.gmt")

All_pathway_DB <- getGmt("/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/code/genesets/c2.all.v2025.1.Hs.symbols.gmt")

## ssGSEA Fuction
ssGSEA <- function(matrix, geneset, group1, group2) {
  if (geneset == "KEGG") {
    ssg_res <- gsva(matrix, KEGG,
                    min.sz = 10, max.sz = 300,
                    method = "gsva",
                    verbose = TRUE, parallel.sz = 18
    )
  } else if (geneset == "Hall_mark") {
    ssg_res <- gsva(matrix, Hall_mark,
                    min.sz = 10, max.sz = 300,
                    method = "gsva",
                    verbose = TRUE, parallel.sz = 18
    )
  } else if (geneset == "Reactome") {
    ssg_res <- gsva(matrix, Reactome,
                    min.sz = 10, max.sz = 300,
                    method = "gsva",
                    verbose = TRUE, parallel.sz = 18
    )
  } else if (geneset == "GO_BP") {
    ssg_res <- gsva(matrix, GO_BP,
                    min.sz = 10, max.sz = 300,
                    method = "gsva",
                    verbose = TRUE, parallel.sz = 18
    )
  }  else {
    print("Please provide the correct data set")
  }
  ## ----- run limma to find differential pathway ---------------------------------
  design <- model.matrix(~ factor(meta$type))
  colnames(design) <- c(group1, paste(group1, "Vs", group2))
  fit <- eBayes(lmFit(ssg_res, design))
  diffPath <- topTable(fit, coef = paste(group1, "Vs", group2), number = Inf)
  ## ------to plot we take top 20 pathways by logFC -------------------------------
  diffPath <- sortByCol(diffPath, c("logFC"))
  topPathways <- c(rev(rownames(diffPath))[1:20], rownames(diffPath)[1:20])
  mat <- ssg_res[topPathways, ]
  enrichment_pathway <- data.frame(diffPath)
  top20_pathway <- data.frame(mat)
  # Print results objects to workspace
  write.csv(ssg_res, paste(getwd(), geneset, paste("ssGSEA_results", ".csv", sep = ""), sep = "/"))
  write.csv(enrichment_pathway, paste(getwd(), geneset, paste("ssGSEA_results_pvalue", ".csv", sep = ""), sep = "/"))
  write.csv(top20_pathway, paste(getwd(), geneset, paste("top20_pathway", ".csv", sep = ""), sep = "/"))
  # write.csv(enrichment_pathway,"/Users/ranpeng/Desktop/CCA-data/2021-1-18/HBV/ssGSEA_results_pvalue.csv")
  # write.csv(enrichment_pathway,"/Users/ranpeng/Desktop/CCA-data/2021-1-18/HBV/top20_pathway.csv")
  ## -----------------------format pathway names ----------------------------------
  rownames(mat) <- gsub("_", " ", rownames(mat))
  rownames(mat) <- gsub("KEGG ", "", rownames(mat))
  ## -----------------------format pathway names 大小写转换 -----------------------
  pathway_name <- rownames(mat)
  pathway_name <- tolower(pathway_name) ## 将x中的字符全部转换为小写字母
  # pathway_name <- capitalize(pathway_name) ## 将y中的字符全部转换为大写字母
  rownames(mat) <- pathway_name
  
  if (TRUE) {
    topAnn <- HeatmapAnnotation(
      df = meta[, "type", drop = F],
      col = list(type = c("Non_responder" = "#386770", "Responder" = "#9BC9D2")),
      annotation_height = unit(1, "cm")
    )
    heat.col <- colorRamp2(c(-0.5, 0, 0.5), c("#2166ac", "#f7f7f7", "red")) ## 原始图例c('#2166ac', '#f7f7f7', '#b2182b'))
    ht <- Heatmap(mat,
                  name = "GSVA score", col = heat.col, top_annotation = topAnn,
                  cluster_rows = F, cluster_columns = F, show_column_names = F,
                  row_names_side = "left"
    )
    ## pdf oupput pathway
    pdf(paste(getwd(), geneset, paste("top_20_pathway", ".pdf", sep = ""), sep = "/"), height = 7, width = 8)
    maxChar <- rownames(mat)[nchar(rownames(mat)) == max(nchar(rownames(mat)))]
    padding <- unit.c(
      unit(2, "mm"),
      grobWidth(textGrob(maxChar)) - unit(50, "mm"),
      unit(c(2, 2), "mm")
    )
    draw(ht, padding = padding, merge_legends = TRUE)
    dev.off()
  }
  
  # Initialize a data frame to store all differential genes
  all_diff_genes <- data.frame()
  
  # Run limma for each pathway
  for (pathway in rownames(ssg_res)) {
    # Subset the matrix for the current pathway
    pathway_matrix <- matrix[rownames(matrix) %in% pathway, ]
    
    # Check if pathway_matrix is empty
    if (nrow(pathway_matrix) == 0) {
      print(paste("Skipping pathway", pathway, "because it has no genes in the input matrix."))
      next  # Skip to the next pathway
    }
    
    # Run limma
    design <- model.matrix(~ factor(meta$type))
    colnames(design) <- c(group1, paste(group1, "Vs", group2))
    fit <- eBayes(lmFit(pathway_matrix, design))
    diff_genes <- topTable(fit, coef = paste(group1, "Vs", group2), number = Inf)
    
    # Adjust the thresholds for selecting significant genes
    p_value_threshold = 0.25  # Set your desired p-value threshold
    logFC_threshold = 0.15  # Set your desired logFC threshold
    
    # Select significant genes based on the new thresholds
    sig_genes <- diff_genes[diff_genes$adj.P.Val < p_value_threshold & abs(diff_genes$logFC) > logFC_threshold, ]
    
    # Store the significant genes for the current pathway
    differential_genes[[pathway]] <- rownames(sig_genes)
    
    # Add differential genes to the all_diff_genes data frame
    diff_genes_df <- data.frame(
      Pathway = pathway,  # Add pathway name
      Gene = rownames(sig_genes)  # Add gene names
    )
    all_diff_genes <- rbind(all_diff_genes, diff_genes_df)
  }
  
  # Write all differential genes to file
  all_diff_genes_filename <- paste(getwd(), geneset, "all_diff_genes.csv", sep = "/")
  write.csv(all_diff_genes, all_diff_genes_filename, row.names = FALSE)
  
}


#' Perform ssGSEA analysis with automated error handling and version compatibility
#'
#' @param matrix Expression matrix (genes x samples)
#' @param geneset Name of gene set ("KEGG", "Hall_mark", "Reactome", "GO_BP", "All_pathway_DB")
#' @param group1 Name of first comparison group
#' @param group2 Name of second comparison group
#' @param min.sz Minimum gene set size (default: 10)
#' @param max.sz Maximum gene set size (default: 300)
#' @param parallel.sz Number of cores for parallel processing (default: 4)
#' @param verbose Print progress messages (default: TRUE)
#' @param p_thresh Adjusted p-value threshold for differential genes (default: 0.25)
#' @param fc_thresh logFC threshold for differential genes (default: 0.15)
#' @param output_dir Base output directory path
#' @return List containing GSVA results, differential pathways, and differential genes
#' @export
optimized_ssGSEA <- function(matrix, geneset, group1, group2, 
                             min.sz = 10, max.sz = 300, 
                             parallel.sz = 4, verbose = TRUE,
                             p_thresh = 0.25, fc_thresh = 0.15,
                             output_dir = getwd()) {
  
  # 1. Package Management with Fallback --------------------------------------
  suppressPackageStartupMessages({
    required_pkgs <- c("GSVA", "limma", "ComplexHeatmap", "circlize", 
                       "BiocParallel", "matrixStats", "tools")
    
    # Install missing packages
    if (!requireNamespace("BiocManager", quietly = TRUE))
      install.packages("BiocManager")
    
    for (pkg in required_pkgs) {
      if (!requireNamespace(pkg, quietly = TRUE)) {
        BiocManager::install(pkg)
      }
      suppressMessages(library(pkg, character.only = TRUE))
    }
    
    # Version compatibility workaround
    if (packageVersion("matrixStats") >= "0.60.0") {
      if (!exists("rowVars", envir = getNamespace("GSVA"), inherits = FALSE)) {
        # Alternative patch for GSVA's internal function
        gsva_ns <- getNamespace("GSVA")
        unlockBinding("rowVars", gsva_ns)
        assign("rowVars", 
               function(x, rows = NULL, cols = NULL, na.rm = FALSE, 
                        center = NULL, dim. = dim(x), ..., useNames = TRUE) {
                 matrixStats::rowVars(x, rows = rows, cols = cols, 
                                      na.rm = na.rm, center = center, 
                                      dim. = dim., ..., useNames = useNames)
               },
               envir = gsva_ns)
        lockBinding("rowVars", gsva_ns)
      }
    }
  })
  
  # 2. Input Validation ------------------------------------------------------
  if (!is.matrix(matrix)) {
    matrix <- as.matrix(matrix)
    storage.mode(matrix) <- "numeric"
  }
  
  if (!exists("meta")) {
    stop("Metadata object 'meta' not found in environment")
  }
  
  valid_genesets <- c("KEGG", "Hall_mark", "Reactome", "GO_BP", "All_pathway_DB")
  if (!geneset %in% valid_genesets) {
    stop(paste("Invalid geneset. Choose from:", paste(valid_genesets, collapse = ", ")))
  }
  
  gset <- get(geneset, envir = .GlobalEnv)
  if (!is.list(gset)) {
    stop(paste(geneset, "is not a valid gene set list"))
  }
  
  # 3. GSVA Analysis --------------------------------------------------------
  message("\n[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "] Running GSVA for ", geneset)
  
  tryCatch({
    ssg_res <- gsva(matrix, gset,
                    min.sz = min.sz, 
                    max.sz = max.sz,
                    method = "gsva",
                    verbose = verbose, 
                    parallel.sz = parallel.sz,
                    BPPARAM = MulticoreParam(workers = parallel.sz))
  }, error = function(e) {
    message("Parallel GSVA failed (", e$message, "), retrying with single core...")
    ssg_res <<- gsva(matrix, gset,
                     min.sz = min.sz, 
                     max.sz = max.sz,
                     method = "gsva",
                     verbose = verbose,
                     parallel.sz = 1)
  })
  
  # 4. Differential Analysis ------------------------------------------------
  message("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "] Performing differential analysis")
  
  design <- model.matrix(~ factor(meta$type))
  colnames(design) <- c(group1, paste0(group1, "_vs_", group2))
  
  fit <- lmFit(ssg_res, design) %>% eBayes()
  diffPath <- topTable(fit, coef = paste0(group1, "_vs_", group2), number = Inf)
  
  # 5. Prepare Results ------------------------------------------------------
  top20 <- prepare_top_pathways(diffPath, ssg_res)
  geneset_dir <- file.path(output_dir, geneset)
  if (!dir.exists(geneset_dir)) dir.create(geneset_dir, recursive = TRUE)
  
  
  
  # 6. Save Outputs --------------------------------------------------------
  save_analysis_results(geneset_dir, ssg_res, diffPath, top20$mat, geneset)
  generate_heatmap(top20$mat, meta, geneset_dir, geneset)
  diff_genes <- find_differential_genes(matrix, ssg_res, meta, group1, group2, 
                                        p_thresh, fc_thresh, gset)
  
  # 7. Return Results ------------------------------------------------------
  message("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "] ", geneset, " analysis completed\n")
  
  list(gsva_results = ssg_res,
       diff_pathways = diffPath,
       diff_genes = diff_genes,
       heatmap_matrix = top20$mat)
}           
                        
# Helper functions
prepare_top_pathways <- function(diffPath, ssg_res, n = 20) {
  diffPath <- diffPath[order(diffPath$logFC, decreasing = TRUE), ]
  topPathways <- c(head(rownames(diffPath), n), tail(rownames(diffPath), n))
  mat <- ssg_res[topPathways, ]
  
  # Format pathway names
  rownames(mat) <- gsub("_", " ", rownames(mat))
  rownames(mat) <- gsub("^KEGG\\s+|^REACTOME\\s+|^GOBP\\s+", "", rownames(mat), ignore.case = TRUE)
  rownames(mat) <- tools::toTitleCase(tolower(rownames(mat)))
  
  list(mat = mat, diffPath = diffPath)
}

save_results <- function(output_dir, ssg_res, diffPath, top_mat, geneset) {
  write.csv(ssg_res, file.path(output_dir, paste0("ssGSEA_results_", geneset, ".csv")))
  write.csv(diffPath, file.path(output_dir, paste0("ssGSEA_results_pvalue_", geneset, ".csv")))
  write.csv(top_mat, file.path(output_dir, paste0("top20_pathway_", geneset, ".csv")))
}

generate_heatmap <- function(mat, meta, output_dir, geneset) {
  # Annotation colors
  ann_colors <- list(type = c("NR" = "#386770", "R" = "#9BC9D2"))
  
  # Heatmap colors
  heat.col <- colorRamp2(c(-0.5, 0, 0.5), c("#2166ac", "#f7f7f7", "red"))
  
  # Column annotation
  topAnn <- HeatmapAnnotation(
    df = meta["type"],
    col = ann_colors,
    annotation_height = unit(1, "cm"),
    show_annotation_name = FALSE
  )
  
  # Create heatmap
  ht <- Heatmap(mat,
                name = "GSVA score", 
                col = heat.col, 
                top_annotation = topAnn,
                cluster_rows = FALSE, 
                cluster_columns = FALSE, 
                show_column_names = FALSE,
                row_names_side = "left",
                row_names_gp = gpar(fontsize = 10))
  
  # Save to PDF
  pdf(file.path(output_dir, paste0("top20_pathway_", geneset, ".pdf")), 
      height = 7, width = 8)
  draw(ht)
  dev.off()
}

find_differential_genes <- function(matrix, ssg_res, meta, group1, group2, 
                                    p_thresh = 0.25, fc_thresh = 0.15) {
  all_diff_genes <- data.frame()
  
  for (pathway in rownames(ssg_res)) {
    pathway_genes <- intersect(rownames(matrix), unlist(KEGG[[pathway]]))
    
    if (length(pathway_genes) == 0) {
      message("Skipping ", pathway, " - no genes in matrix")
      next
    }
    
    pathway_matrix <- matrix[pathway_genes, , drop = FALSE]
    
    design <- model.matrix(~ factor(meta$type))
    colnames(design) <- c(group1, paste0(group1, "_vs_", group2))
    
    fit <- lmFit(pathway_matrix, design) %>% eBayes()
    diff_genes <- topTable(fit, coef = paste0(group1, "_vs_", group2), number = Inf)
    
    sig_genes <- diff_genes[diff_genes$adj.P.Val < p_thresh & abs(diff_genes$logFC) > fc_thresh, ]
    
    if (nrow(sig_genes) > 0) {
      all_diff_genes <- rbind(all_diff_genes,
                              data.frame(Pathway = pathway,
                                         Gene = rownames(sig_genes),
                                         logFC = sig_genes$logFC,
                                         adj.P.Val = sig_genes$adj.P.Val))
    }
  }
  
  return(all_diff_genes)
}

# Usage example:
results <- optimized_ssGSEA(matrix, "KEGG", "NR", "R")


#' Perform ssGSEA analysis with differential pathway and gene analysis
#'
#' @param matrix Gene expression matrix (genes as rows, samples as columns)
#' @param geneset Name of gene set to use ("KEGG", "Hall_mark", "Reactome", "GO_BP")
#' @param group1 Name of first group (control/reference group)
#' @param group2 Name of second group (comparison group)
#' @param meta Data frame with sample metadata (must contain 'type' column)
#' @param output_dir Directory to save results (default = current working directory)
#' @param pval_threshold Adjusted p-value threshold for differential genes (default = 0.25)
#' @param logFC_threshold logFC threshold for differential genes (default = 0.15)
#' @param top_n Number of top pathways to display (default = 20)
#' @param cores Number of cores for parallel processing (default = 18)
#'
#' @return List containing ssGSEA results, differential pathways, and differential genes
#' @export
ssGSEA <- function(matrix, geneset, group1, group2, meta,  # Added meta as required parameter
                   output_dir = getwd(), pval_threshold = 0.25, 
                   logFC_threshold = 0.15, top_n = 20, cores = 18) {
  
  # Load required libraries
  require(GSVA)
  require(limma)
  require(ComplexHeatmap)
  require(circlize)
  
  # Set useNames parameter explicitly
  options(matrixStats.useNames = FALSE)
  # Validate inputs
  if (!geneset %in% c("KEGG", "Hall_mark", "Reactome", "GO_BP")) {
    stop("Invalid geneset. Please use one of: 'KEGG', 'Hall_mark', 'Reactome', 'GO_BP'")
  }
  
  if (!"type" %in% colnames(meta)) {
    stop("Metadata must contain 'type' column")
  }
  
  if (!all(colnames(matrix) %in% rownames(meta))) {
    stop("Sample names in matrix and metadata don't match")
  }
  
  # Create output directory if it doesn't exist
  geneset_dir <- file.path(output_dir, geneset)
  if (!dir.exists(geneset_dir)) {
    dir.create(geneset_dir, recursive = TRUE)
  }
  
  # Select appropriate gene set
  gset <- switch(geneset,
                 "KEGG" = KEGG,
                 "Hall_mark" = Hall_mark,
                 "Reactome" = Reactome,
                 "GO_BP" = GO_BP)
  
  # Run GSVA
  message("Running GSVA...")
  ssg_res <- GSVA::gsva(
    expr = matrix,
    gset.idx.list = gset,
    method = "gsva",
    min.sz = 10,
    max.sz = 300,
    parallel.sz = cores,
    verbose = TRUE,
    useNames = TRUE
  )
  
  # Differential pathway analysis
  message("Performing differential pathway analysis...")
  design <- model.matrix(~ factor(meta$type))
  colnames(design) <- c(group1, paste(group1, "Vs", group2))
  fit <- eBayes(lmFit(ssg_res, design))
  diffPath <- topTable(fit, coef = paste(group1, "Vs", group2), number = Inf)
  
  # Save results
  message("Saving results...")
  write.csv(ssg_res, file.path(geneset_dir, "ssGSEA_results.csv"))
  write.csv(diffPath, file.path(geneset_dir, "ssGSEA_results_pvalue.csv"))
  
  # Prepare top pathways for visualization
  diffPath <- diffPath[order(diffPath$logFC, decreasing = TRUE), ]
  topPathways <- c(rownames(diffPath)[1:top_n], 
                   rev(rownames(diffPath))[1:top_n])
  mat <- ssg_res[intersect(topPathways, rownames(ssg_res)), ]
  write.csv(mat, file.path(geneset_dir, "top_pathways.csv"))
  
  # Format pathway names
  rownames(mat) <- gsub("_", " ", rownames(mat))
  rownames(mat) <- gsub(paste0(geneset, " "), "", rownames(mat))
  rownames(mat) <- tools::toTitleCase(tolower(rownames(mat)))
  
  # Create heatmap
  message("Creating heatmap...")
  topAnn <- HeatmapAnnotation(
    df = meta[, "type", drop = FALSE],
    col = list(type = c("NR" = "#386770", "R" = "#9BC9D2")),
    annotation_height = unit(1, "cm")
  )
  
  heat.col <- colorRamp2(c(-0.5, 0, 0.5), c("#2166ac", "#f7f7f7", "red"))
  ht <- Heatmap(mat,
                name = "GSVA score", 
                col = heat.col, 
                top_annotation = topAnn,
                cluster_rows = FALSE, 
                cluster_columns = FALSE, 
                show_column_names = FALSE,
                row_names_side = "left"
  )
  
  # Save heatmap
  pdf(file.path(geneset_dir, "top_pathways.pdf"), height = 7, width = 8)
  maxChar <- rownames(mat)[which.max(nchar(rownames(mat)))]
  padding <- unit.c(
    unit(2, "mm"),
    grobWidth(textGrob(maxChar)) - unit(50, "mm"),
    unit(c(2, 2), "mm")
  )
  draw(ht, padding = padding, merge_legends = TRUE)
  dev.off()
  
  # Differential gene analysis for each pathway
  message("Performing differential gene analysis for pathways...")
  all_diff_genes <- data.frame()
  differential_genes <- list()
  
  for (pathway in rownames(ssg_res)) {
    pathway_genes <- intersect(rownames(matrix), gset[[pathway]])
    
    if (length(pathway_genes) == 0) {
      message(sprintf("Skipping pathway %s - no genes in matrix", pathway))
      next
    }
    
    pathway_matrix <- as.matrix(matrix[pathway_genes, , drop = FALSE])
    mode(pathway_matrix) <- "numeric"
    
    fit <- eBayes(lmFit(pathway_matrix, design))
    coef_name <- colnames(design)[2]  # 或者你自己确认正确列名
    diff_genes <- topTable(fit, coef = coef_name, number = Inf)
    
    sig_genes <- diff_genes[diff_genes$adj.P.Val < pval_threshold &
                              abs(diff_genes$logFC) > logFC_threshold, ]
    
    if (nrow(sig_genes) > 0) {
      differential_genes[[pathway]] <- rownames(sig_genes)
      diff_genes_df <- data.frame(
        Pathway = pathway,
        Gene = rownames(sig_genes),
        logFC = sig_genes$logFC,
        adj.P.Val = sig_genes$adj.P.Val,
        stringsAsFactors = FALSE
      )
      all_diff_genes <- rbind(all_diff_genes, diff_genes_df)
    }
  }
  
  # Return results
  return(list(
    ssGSEA_results = ssg_res,
    differential_pathways = diffPath,
    differential_genes = all_diff_genes,
    heatmap = ht
  ))
}

create_heatmap_annotation <- function(meta, group1, group2) {
  # 确保 group1 和 group2 是有效的名称
  if (missing(group1) | missing(group2)) {
    stop("Both group1 and group2 need to be specified.")
  }
  
  # 动态构建颜色映射
  type_colors <- c(group1 = "#9BC9D2", group2 =  "#386770")
  names(type_colors) <- c(group1, group2)  # 确保名称匹配
  
  # 创建 HeatmapAnnotation
  topAnn <- HeatmapAnnotation(
    df = meta[, "type", drop = FALSE], 
    col = list(type = type_colors),  # 使用动态的颜色映射
    annotation_height = unit(1, "cm")
  )
  
  return(topAnn)
}

ssGSEA <- function(matrix, geneset, group1, group2, meta, 
                   output_dir = getwd(), pval_threshold = 0.25, 
                   logFC_threshold = 0.15, top_n = 20, cores = 8) {
  
  # Load required libraries
  library(GSVA)
  library(limma)
  library(ComplexHeatmap)
  library(circlize)
  
  # Validate inputs
  if (!geneset %in% c("KEGG", "Hall_mark", "Reactome", "GO_BP", "All_pathway_DB")) {
    stop("Invalid geneset. Please use one of: 'KEGG', 'Hall_mark', 'Reactome', 'GO_BP', 'All_pathway_DB'")
  }
  
  if (!"type" %in% colnames(meta)) {
    stop("Metadata must contain 'type' column")
  }
  
  if (!all(colnames(matrix) %in% rownames(meta))) {
    stop("Sample names in matrix and metadata don't match")
  }
  
  # Create output directory if it doesn't exist
  geneset_dir <- file.path(output_dir, geneset)
  if (!dir.exists(geneset_dir)) {
    dir.create(geneset_dir, recursive = TRUE)
  }
  
  # Select appropriate gene set
  gset <- switch(geneset,
                 "KEGG" = KEGG,
                 "Hall_mark" = Hall_mark,
                 "Reactome" = Reactome,
                 "GO_BP" = GO_BP,
                 "All_pathway_DB" = All_pathway_DB)
  
  # Run GSVA
  message("Running GSVA...")
  ssg_res <- GSVA::gsva(
    expr = matrix,
    gset.idx.list = gset,
    method = "gsva",
    min.sz = 10,
    max.sz = 300,
    parallel.sz = cores,
    verbose = TRUE
  )
  
  # Differential pathway analysis
  message("Performing differential pathway analysis...")
  design <- model.matrix(~ factor(meta$type))
  colnames(design) <- c(group1, paste(group1, "Vs", group2))
  fit <- eBayes(lmFit(ssg_res, design))
  diffPath <- topTable(fit, coef = paste(group1, "Vs", group2), number = Inf)
  
  # Save results
  message("Saving results...")
  write.csv(ssg_res, file.path(geneset_dir, "ssGSEA_results.csv"))
  write.csv(diffPath, file.path(geneset_dir, "ssGSEA_results_pvalue.csv"))
  
  # Prepare top pathways for visualization
  diffPath <- diffPath[order(diffPath$logFC, decreasing = TRUE), ]
  topPathways <- c(rownames(diffPath)[1:top_n], 
                   rev(rownames(diffPath))[1:top_n])
  mat <- ssg_res[intersect(topPathways, rownames(ssg_res)), ]
  write.csv(mat, file.path(geneset_dir, "top_pathways.csv"))
  
  # Format pathway names
  rownames(mat) <- gsub("_", " ", rownames(mat))
  rownames(mat) <- gsub(paste0(geneset, " "), "", rownames(mat))
  rownames(mat) <- tools::toTitleCase(tolower(rownames(mat)))
  
  # Create heatmap
  message("Creating heatmap...")
  topAnn <- create_heatmap_annotation(meta, group1, group2)
  # topAnn <- HeatmapAnnotation(
  #   df = meta[, "type", drop = FALSE],
  #   col = list(type = c("Non_responder" = "#386770", "Responder" = "#9BC9D2")),
  #   annotation_height = unit(1, "cm")
  # )
  # 
  heat.col <- colorRamp2(c(-0.5, 0, 0.5), c("#2166ac", "#f7f7f7", "red"))
  ht <- Heatmap(mat,
                name = "GSVA score", 
                col = heat.col, 
                top_annotation = topAnn,
                cluster_rows = FALSE, 
                cluster_columns = FALSE, 
                show_column_names = FALSE,
                row_names_side = "left"
  )
  
  # Save heatmap
  pdf(file.path(geneset_dir, "top_pathways.pdf"), height = 7, width = 14)
  maxChar <- rownames(mat)[which.max(nchar(rownames(mat)))]
  padding <- unit.c(
    unit(2, "mm"),
    grobWidth(textGrob(maxChar)) - unit(50, "mm"),
    unit(c(2, 2), "mm")
  )
  draw(ht, padding = padding, merge_legends = TRUE)
  dev.off()
  
  # ---------  Differential gene analysis for each pathway  -------------
  # 定义函数：提取KEGG通路及对应的基因
  extract_genes_from_gmt <- function(gmt_file) {
    
    # 提取每个通路和对应的基因
    pathway_genes <- list()
    
    # 遍历 gene_sets，提取每个通路的基因
    for (pathway in names(gmt_file)) {
      # 提取 GeneSet 中的基因
      genes <- geneIds(gmt_file[[pathway]])  # 从 GeneSet 提取基因
      pathway_genes[[pathway]] <- as.character(genes)  # 转换为字符向量
    }
    
    return(pathway_genes)
  }
  
  # --------- Differential gene analysis for each pathway -------------
  message("Performing differential gene analysis for pathways...")
  
  # Initialize a list to store differential genes (more efficient than growing data.frame)
  differential_genes <- list()  # Store the differential genes for each pathway
  all_diff_genes <- data.frame(Pathway = character(), Gene = character(), 
                               logFC = numeric(), AveExpr = numeric(), t = numeric(),
                               P.Value = numeric(), adj.P.Val = numeric(), B = numeric(), 
                               stringsAsFactors = FALSE)
  
  geneSets <- extract_genes_from_gmt(gset)
  
  # Assuming 'ssg_res' is the result of pathway analysis
  # Iterating over each pathway in ssg_res to perform differential gene analysis
  for (pathway in rownames(ssg_res)) {
    # Extract the genes for the current pathway from the GMT file
    pathway_genes <- geneSets[[pathway]]  # 提取该通路的基因集
    
    # If no genes are found for the pathway, skip it
    if (length(pathway_genes) == 0) {
      message(sprintf("Skipping pathway %s because no genes found in the gene set.", pathway))
      next
    }
    
    # Subset the matrix to only include the genes in the current pathway
    pathway_matrix <- matrix[rownames(matrix) %in% pathway_genes, , drop = FALSE]
    
    # If no genes from the pathway are found in the matrix, skip it
    if (nrow(pathway_matrix) == 0) {
      message(sprintf("Skipping pathway %s because it has no genes in the input matrix.", pathway))
      next
    }
    
    # Run limma
    design <- model.matrix(~ factor(meta$type))
    colnames(design) <- c(group1, paste(group1, "Vs", group2))
    fit <- eBayes(lmFit(pathway_matrix, design))
    diff_genes <- topTable(fit, coef = paste(group1, "Vs", group2), number = Inf)
    
    # Filter significant genes
    p_value_threshold <- 0.25
    logFC_threshold <- 0.15
    sig_genes <- diff_genes[diff_genes$adj.P.Val < p_value_threshold & abs(diff_genes$logFC) > logFC_threshold, , drop = FALSE]
    
    if (nrow(sig_genes) > 0) {
      # Filter out genes that are in the differential genes list and in the gene set
      pathway_diff_genes <- intersect(rownames(sig_genes), pathway_genes)
      
      if (length(pathway_diff_genes) > 0) {
        # Store the differential genes and their details for the current pathway
        for (gene in pathway_diff_genes) {
          gene_details <- sig_genes[gene, c("logFC", "AveExpr", "t", "P.Value", "adj.P.Val", "B")]
          all_diff_genes <- rbind(all_diff_genes, 
                                  data.frame(Pathway = pathway,
                                             Gene = gene,
                                             logFC = gene_details$logFC,
                                             AveExpr = gene_details$AveExpr,
                                             t = gene_details$t,
                                             P.Value = gene_details$P.Value,
                                             adj.P.Val = gene_details$adj.P.Val,
                                             B = gene_details$B,
                                             stringsAsFactors = FALSE))
        }
      }
    }
  }
  
  # Write all differential genes to file
  all_diff_genes_filename <- file.path(output_dir, geneset, "all_diff_genes.csv")
  write.csv(all_diff_genes, all_diff_genes_filename, row.names = FALSE)
  
  # Return results
  return(list(
    ssGSEA_results = ssg_res,
    differential_pathways = diffPath,
    differential_genes = all_diff_genes,
    heatmap = ht
  ))
}

if(TRUE){
  
  input_path <- "/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/Chemo_Immuno/RNA_matrix_FPKM_tnm.csv"
  anno_path <- "/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/Chemo_Immuno/RNA_matrix_ana.csv"
  input_data <- read.csv(input_path, header = T, row.names = 1, stringsAsFactors = F)
  meta <- read.csv(anno_path, header = T, row.names = 1, stringsAsFactors = F)
  matrix <- as.matrix(input_data)
  
  ## 数据存储路径
  setwd("/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/Chemo_Immuno/GSVA_pathway/")
  outpath <- getwd()
  
  ## 创建路径
  KEGG_result <- paste(outpath, "KEGG", sep = "/")
  Hall_mark_result <- paste(outpath, "Hall_mark", sep = "/")
  Reactome_result <- paste(outpath, "Reactome", sep = "/")
  GO_BP_result <- paste(outpath, "GO_BP", sep = "/")
  All_pathway_DB_result <- paste(outpath, "All_pathway_DB", sep = "/")

  # Vector of directory paths
  dir_paths <- c(KEGG_result, Hall_mark_result, Reactome_result, 
                 GO_BP_result, All_pathway_DB_result)
  
  # Create directories that don't exist (with recursive parent creation)
  sapply(dir_paths, function(path) {
    if (!dir.exists(path)) {
      dir.create(path, recursive = TRUE)
      cat("Created directory:", path, "\n")
    } else {
      cat("Directory exists:", path, "\n")
    }
  })
  
  # "KEGG", "Hall_mark", "Reactome",
  for (geneset in c("KEGG", "Hall_mark", "Reactome","GO_BP", "All_pathway_DB")) {
    try(ssGSEA(matrix, geneset, "Non_responder", "Responder", meta))
  }
}

try(ssGSEA(matrix, "KEGG", "Non_responder", "Responder", meta))



# 获取所有癌症类型

meta1 <- read.csv("/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/Chemo_Immuno/RNA_matrix_ana_v2.csv",
                 header = T, row.names = 1, stringsAsFactors = F)
cancer_types <- unique(meta1$Group)

# 创建一个副本 df 用于操作
df <- as.data.frame(meta1)

# 创建一个输出路径变量
outpath <- "/Volumes/Extreme_Pro/Samsung_T5/东方肝胆外科合作项目/data/RNA-seq/Chemo_Immuno/GSVA_pathway_v2"  # 请替换为你的输出路径

## 创建路径
KEGG_result <- paste(outpath, "KEGG", sep = "/")
Hall_mark_result <- paste(outpath, "Hall_mark", sep = "/")
Reactome_result <- paste(outpath, "Reactome", sep = "/")
GO_BP_result <- paste(outpath, "GO_BP", sep = "/")
All_pathway_DB_result <- paste(outpath, "All_pathway_DB", sep = "/")

# Vector of directory paths
dir_paths <- c(KEGG_result, Hall_mark_result, Reactome_result, 
               GO_BP_result, All_pathway_DB_result)

# Create directories that don't exist (with recursive parent creation)
sapply(dir_paths, function(path) {
  if (!dir.exists(path)) {
    dir.create(path, recursive = TRUE)
    cat("Created directory:", path, "\n")
  } else {
    cat("Directory exists:", path, "\n")
  }
})

# 进行循环处理每种癌症类型

for (cancer in cancer_types) {
  # 创建一个新的 'Group' 列，将该癌症类型标记为 "cancer" 组，其他标记为 "The Rest"
  df <- df %>%
    mutate(type = ifelse(Group == cancer, cancer, "The Rest"))
  
  KEGG_result <- paste(outpath, "KEGG", cancer, sep = "/")
  Hall_mark_result <- paste(outpath, "Hall_mark", cancer, sep = "/")
  Reactome_result <- paste(outpath, "Reactome", cancer, sep = "/")
  GO_BP_result <- paste(outpath, "GO_BP", cancer, sep = "/")
  All_pathway_DB_result <- paste(outpath, "All_pathway_DB", sep = "/")
  
  # Vector of directory paths
  dir_paths <- c(KEGG_result, Hall_mark_result, Reactome_result, 
                 GO_BP_result, All_pathway_DB_result)
  
  # Create directories that don't exist (with recursive parent creation)
  sapply(dir_paths, function(path) {
    if (!dir.exists(path)) {
      dir.create(path, recursive = TRUE)
      cat("Created directory:", path, "\n")
    } else {
      cat("Directory exists:", path, "\n")
    }
  })
  
  # 如果 'Group' 列中只有两种不同的组别
  if (length(unique(df$type)) == 2) {
    # 调用一个函数来计算组间差异，返回结果
    # "KEGG", "Hall_mark", "Reactome",
    genesets <- c("KEGG", "Hall_mark", "Reactome", "GO_BP")
    output_paths <- c(KEGG_result, Hall_mark_result, Reactome_result, GO_BP_result)
    
    for (i in seq_along(genesets)) {
      geneset <- genesets[i]
      out_path <- output_paths[i]
      try(ssGSEA(matrix, geneset, group1 = "The Rest", group2 = cancer, meta=df, output_dir = out_path))
    }
  }
}

