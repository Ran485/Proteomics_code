library(ggplot2)



ggplot(driverExpression,aes(x=reorder(Hugo,logFC),y=(logFC),color=expression))+
geom_point(aes(size= -log10(FDR)))+
geom_hline(yintercept=0,color="black", linetype="dotted")+
labs(x="",y="log FC pCR")+
coord_flip()+
scale_colour_manual(values = c("#FB6542","#375E97",))+
scale_size_continuous(name=expression(italic(-log[10]~FDR)),breaks = c(2:4))+
guides(color="none")+
theme_manuscript(base_size = figure_font_size)+
theme(panel.grid.major.y = element_blank(),
      axis.text.y = element_text(face="italic"),
      plot.margin = unit(c(1.1,1.5,0,0.5), "lines"))

