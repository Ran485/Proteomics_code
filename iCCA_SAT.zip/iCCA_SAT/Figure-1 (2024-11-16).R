
## ================ Panel=Fig1B - gene mutation oncoprint ========================

## --------------- Synonymous and Non_Synonymous mutation stacked plot ------------------
library(plyr)
library(ggplot2)

df = read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/Non_Synonymous_mutation_summary_v2.csv", row.names = 1)
# df = read.csv("/Users/ranpeng/Desktop/Integrated_multiomics_analysis_CCA/data/Fig1/fig1b/mutation_barplot_input.csv", row.names = 1)
# /Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/Non_Synonymous_mutation_summary_v2.csv
colnames(df)
df$count = ifelse(df$count >= 1500, 1500, df$count)
# Create the barplot
ggplot(data=df, aes(x=num, y=count, fill=mutation_type)) +
  geom_bar(stat="identity")+
  # geom_text(aes(y=label_ypos, label=len), vjust=1.6, 
  #           color="white", size=3.5)+
  scale_fill_brewer(palette="Paired")+
  # xlim(0,25) +
  ylim(0,1500) +
  labs(title="Significantly mutated genes", x="Mutation frequency (%)", y = "-Log10 (FDR)")+
  # theme(panel.border = element_blank(), panel.grid.major = element_blank(),
  #       panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+
  theme(axis.text.x=element_text(angle=0,hjust = 0.6,colour="black",family="Arial",size=16), 
        axis.title.x=element_text(angle=0,hjust = 0.5,colour="black",family="Arial",size=20),
        axis.text.y=element_text(family="Arial",size=16,face="plain"),
        axis.title.y=element_text(family="Arial",size = 20,face="plain"), 
        # panel.border = element_blank(),
        axis.line = element_line(colour = "black",size=0.8),
        legend.text=element_text(face="plain", family="Arial", colour="black", size=12),
        legend.title=element_text(face="plain", family="Arial", colour="black", size=12),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())

## --------------- Clinical information heatmap ------------------
library(pheatmap)
library(RColorBrewer)
# rm(list = ls())
matrix=read.csv("/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/Top32_onco_matrix_binary_v3.csv",header=T,skip = 0,row.names = 1)
# matrix=read.csv("/Users/ranpeng/Desktop/Integrated_multiomics_analysis_CCA/data/Fig1/fig1b/CCA_CNV_plot_20220326_del.csv",header=T,skip = 0,row.names = 1)
#chending_color<-colorRampPalette(c("#3090D1","#FFFFFF","red"))(50)
chending_color<-colorRampPalette(c("#0690F7","#FFFFFF","red"))(50)
#chending_color <- colorRampPalette(brewer.pal(8, "PiYG"))(50)
# Generate annotations for rows and columns
# annotation_col = read.csv ('/Users/ranpeng/Desktop/CCA/Data/Fig1/Figure-1b/figure1_anatation.csv',header = T,row.names = 1)
annotation_col = read.csv ('/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/Fig1_clinical_feature_anatation_v2_20241116.csv',header = T,row.names = 1)
# annotation_col = read.csv ('/Users/ranpeng/Desktop/Integrated_multiomics_analysis_CCA/data/Fig1/fig1b/Fig1b_clinical_feature_anatation_20220326.csv',header = T,row.names = 1)
# ann_colors = list(type = c(iCC_N= "#48cae4", eCC_N = "#f48c06", iCC_T = "#0077b6" , eCC_T = "#dc2f02"))
# annotation_row = read.csv ('/Users/ranpeng/Desktop/胆管癌/data/2020-8-21/annotation_row_all.csv',header = T,row.names = 1)
ann_colors <- list(
  Age = c("#FFFFCB", "#C1E598", "#8BF28B", "#3AC160", "#006837"),
  Gender = c(Female = "#FCBA83", Male = "#E24F3B"),
  Pathology = c(iCCA = "#FFC51A", eCCA = "#a767ff"),
  iCCA_small_moleculor = c(smallBD = "#89BCDF", largeBD = "#2080C3", NA_1 = "#ededed", NA_2 = "#ededed"),
  CCP_Class = c(cluster_1 = "#1F78B4", cluster_2 = "#33A02C", cluster_3 = "#92CFEA", NA_1 = "#ededed"),
  Proteome_Subtype = c(S_I = "#FF800D", S_II = "#0E65AD", S_III = "#FF0027"),
  Grade = c(GX = "#ffe0e9", G1 = "#ffc2d4", G1_2 = "#ff9ebb", G2 = "#ff7aa2", G2_3 = "#e05780", G3 = "#b9375e"),
  TNM_Stage = c(I = "#0272BC", II = "#ABD373", III = "#FCED68", IV = "#F8941D"),
  iccStage = c(IA = "#caf0f8", IB = "#90e0ef", II = "#48cae4", IIIA = "#0096c7", IIIB = "#0077b6", IV = "#023e8a", NA_1 = "#ededed"),
  eccStage = c(I = "#caf0f8", II = "#90e0ef", IIIA = "#48cae4", IIIB = "#0096c7", IIIC = "#0077b6", IVB = "#023e8a", NA_1 = "#ededed"),
  Lymphovascular_invasion = c(No = "#fca311", Yes = "#14213d", Unknown = "#EDEDED"),
  Perineural_invasion = c(No = "#fbd87f", Yes = "#c62c43", Unknown = "#EDEDED"),
  Presence_of_fluke_infection = c(No = "#EDEDED", Yes = "#000000"),
  Type_2_diabetes = c(No = "#EDEDED", Yes = "#14213d"),
  Choledocholithiasis = c(No = "#020202", Yes = "#72D672", Unknown = "#EDEDED"),
  Cholecystolithiasis = c(No = "#020202", Yes = "#72D672", Unknown = "#EDEDED"),
  Cholelithiasis = c(No = "#EDEDED", Yes = "#f5cb5c"),
  Hypertension = c(No = "#EDEDED", Yes = "#086375"),
  CA199 = c(Normal = "#ffa5ab", Elevated = "#bc4877", NA_1 = "#ededed"),
  Tbil = c(Normal = "#1282a2", Elevated = "#034078", NA_1 = "#ededed"),
  ALT = c(Below = "#eff48e", Normal = "#d2e603", Elevated = "#3e978b", NA_1 = "#ededed"),
  GGT = c(Normal = "#68adff", Elevated = "#2b69c9", NA_1 = "#ededed"),
  HBV = c(Ever = "#376770", Never = "#9ac9d2", NA_1 = "#ededed"),
  PT = c(Below = "#e1f48f", Normal = "#f9d073", Elevated = "#e5643c", NA_1 = "#ededed"),
  Response = c(Responder = "#0E9F87", Non_responder = "#3C5588"),
  Response_RECIST = c(PD = "#F04124", SD = "#F8941D", PR = "#34AD40", CR = "#02A595"),
  Progress = c(Progress = "#086375", Non_Progress = "#EDEDED"),
  Status = c(Alive = "#ededed", Dead = "#020202")
  
)


matrix = as.matrix(matrix)
matrix[is.na(matrix)] <- 0
pheatmap(matrix,
         cluster_rows=FALSE, cluster_cols=FALSE,
         # clustering_distance_cols = "correlation",
         # clustering_distance_rows = "correlation",
         # fill = T,
         border_color ="white", na_col = "white",
         col=chending_color,
         show_rownames=T,
         show_colnames=F,
         display_numbers=F,
         # width = 4.85,
         # height = 5,
         fontsize_number=12,number_color="black",
         number_format="%.1f",
         annotation_col = annotation_col , 
         annotation_colors = ann_colors) #, annotation_row = annotation_row)


# Specify colors
ann_colors = list(
  Patient = c(select= "#078DC6"),
  Proteome_N = c(select = "#7CD8AE", Miss = "#E4E4DF"),
  Proteome_T = c(select = "#0EA55D", Miss = "#E4E4DF"),
  Phosphoproteome_N = c(select = "#F78566", Miss = "#E4E4DF"),
  Phosphoproteome_T = c(select = "#E55625", Miss = "#E4E4DF"),
  WES_N = c(select = "#CDB3DD", Miss = "#E4E4DF"),
  WES_T = c(select = "#B076D6", Miss = "#E4E4DF")
)

## --------------- oncoprint_mutation ----------------------

library(ComplexHeatmap)
library(RColorBrewer)

# onco_mat = read.csv('/Volumes/Samsung_T5/downloads/Integrated_multiomics_analysis_CCA/data/Fig1/fig1b/onco_matrix(2022_03_26).csv',header = T, row.names = 1)
onco_mat = read.csv('/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/figs/Top32_onco_matrix.csv',header = T, row.names = 1)

# metadata_sorted = read.csv('/Users/ranpeng/Desktop/2020-12-15/metadata_sorted.csv',header = T)
sample_order<- colnames(onco_mat)

# ================ oncoplot colors ========================

# col = c("Missense_Mutation" = "#EE1D24",
#         "In_Frame_Del" = "#F8941D",
#         "Nonsense_Mutation" = "#FCED68",
#         "Frame_Shift_Del" = "#ABD373",
#         "Splice_Site" = "#39B54A",
#         "Frame_Shift_Ins" = "#00A99D",
#         "In_Frame_Ins" = "#0272BC" ,
#         "Multi_Hit" = "#92278F")

col = c("Missense_Mutation" = "#0085C7",
        "In_Frame_Del" = "#02A595",
        "Nonsense_Mutation" = "#34AD40",
        "Frame_Shift_Del" = "#A3D357",
        "Splice_Site" = "#F4E55B",
        "Frame_Shift_Ins" = "#F8941D",
        "In_Frame_Ins" = "#F04124" ,
        "Multi_Hit" = "#92278F")

# col = c("Missense_Mutation" = "#EE1D24",
#         "In_Frame_Del" = "#F8941D",
#         "Nonsense_Mutation" = "#FCED68",
#         "Frame_Shift_Del" = "#ABD373",
#         "Splice_Site" = "#39B54A",
#         "Frame_Shift_Ins" = "#00A99D",
#         "In_Frame_Ins" = "#0272BC" ,
#         "Multi_Hit" = "#92278F",
#         "FGFR2_fusion" = "#64D8C2")

# just for demonstration
alter_fun = list(
  background = alter_graphic("rect", fill = "#EFF8FD"),	#E5E5E5
  Missense_Mutation = alter_graphic("rect", fill = col["Missense_Mutation"]),
  In_Frame_Del = alter_graphic("rect", fill = col["In_Frame_Del"]),
  Nonsense_Mutation = alter_graphic("rect", height = 1, fill = col["Nonsense_Mutation"]),
  Frame_Shift_Del = alter_graphic("rect", fill = col["Frame_Shift_Del"]),	
  Splice_Site = alter_graphic("rect", fill = col["Splice_Site"]),
  Frame_Shift_Ins = alter_graphic("rect", fill = col["Frame_Shift_Ins"]),
  In_Frame_Ins = alter_graphic("rect", height = 1, fill = col["In_Frame_Ins"]),
  Multi_Hit = alter_graphic("rect", height = 1, fill = col["Multi_Hit"]),
  FGFR2_fusion = alter_graphic("rect", height = 1, fill = col["FGFR2_fusion"])
  # NA_1 = alter_graphic("rect", height = 0.4, fill = col["NA_1"])
  
)
column_title = "OncoPrint of the iCCA"
heatmap_legend_param = list(title = "Alternations", at = c("Missense_Mutation", "In_Frame_Del", "Nonsense_Mutation","Frame_Shift_Del", "Splice_Site", "Frame_Shift_Ins","In_Frame_Ins", "Multi_Hit", "FGFR2_fusion"), 
                            labels = c("Missense_Mutation", "In_Frame_Del", "Nonsense_Mutation","Frame_Shift_Del", "Splice_Site", "Frame_Shift_Ins","In_Frame_Ins", "Multi_Hit", "FGFR2_fusion"))
mix.hp<-oncoPrint(onco_mat,
                  alter_fun = alter_fun, col = col, 
                  remove_empty_columns = F, remove_empty_rows = F, column_order  = sample_order,
                  pct_side = "right", row_names_side = "left", #row_order  = 1:nrow(onco_mat),
                  column_title = column_title, heatmap_legend_param = heatmap_legend_param, show_column_names = F)
draw(mix.hp, heatmap_legend_side = "bottom", annotation_legend_side = "bottom")

## --------------- oncoprint significant CNA ----------------------

# onco_CNA_mat = read.csv('/Users/ranpeng/Desktop/Integrated_multiomics_analysis_CCA/data/Fig1/fig1b/CCA_CNV_oncoplot_20220326.csv',header = T, row.names = 1)
onco_CNA_mat = read.csv('/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/CNV_reaults/iCCA_Oncoplot.csv',header = T, row.names = 1)

# metadata_sorted = read.csv('/Users/ranpeng/Desktop/2020-12-15/metadata_sorted.csv',header = T)
sample_order<- colnames(onco_CNA_mat)
row_order<- rownames(onco_CNA_mat)
# ================ oncoplot colors ========================

col = c("Amp" = "#EA1B2A",
        "gain" = "#FC7581",
        "loss" = "#4E9CF9",
        "Deletion" = "#1B6DCE")

# just for demonstration
alter_fun = list(
  background = alter_graphic("rect", fill = "#EFF8FD"),	#E5E5E5
  Amp = alter_graphic("rect", fill = col["Amp"]),
  gain = alter_graphic("rect", fill = col["gain"]),
  loss = alter_graphic("rect", height = 1, fill = col["loss"]),
  Deletion = alter_graphic("rect", fill = col["Deletion"])
)

column_title = "CNA OncoPrint of the CCA"
heatmap_legend_param = list(title = "Alternations", at = c("Amp", "gain", "Nonsense_Mutation","loss", "Deletion"), 
                            labels = c("Amp", "gain", "Nonsense_Mutation","loss", "Deletion"))
mix.hp<-oncoPrint(onco_CNA_mat,
                  alter_fun = alter_fun, col = col, 
                  remove_empty_columns = F, remove_empty_rows = F, column_order  = sample_order,
                  row_order = row_order,
                  pct_side = "right", row_names_side = "left", #row_order  = 1:nrow(onco_mat),
                  column_title = column_title, heatmap_legend_param = heatmap_legend_param, show_column_names = F)
draw(mix.hp, heatmap_legend_side = "bottom", annotation_legend_side = "bottom")


## --------------- Panel=Fig1F - Mutation signature -----------------------

# BiocManager::install("sigminer", dependencies = TRUE)
## 加载包
library(sigminer)
library(maftools)
library(NMF)
library(BSgenome.Hsapiens.UCSC.hg38) # or hg19
## 数据输入
#laml.maf <- system.file("extdata", "tcga_laml.maf.gz", package = "maftools", mustWork = TRUE)
#laml <- read_maf(maf = laml.maf)
setwd('/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/iCCA_SAT_WES_results/iCCA_SAT_gistic')
# laml.maf = 'Somatic.snv_indel.maf'
# laml <- read_maf(maf = laml.maf)
iCCA_maf = "/Users/ranpeng/Desktop/iCCA_SAT/annotation/funcotator/funcotator_merge.maf"
# clinicalData = "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/WES_metadata.csv"
clinicalData = "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/Fig1_clinical_feature_anatation_20241116.csv"
clincial_metadata = read.csv(clinicalData)

laml <- read.maf(maf = iCCA_maf, clinicalData = clinicalData, gisticAllLesionsFile="all_lesions.conf_90.txt", gisticAmpGenesFile="amp_genes.conf_90.txt", gisticDelGenesFile="del_genes.conf_90.txt", gisticScoresFile="scores.gistic")
samplesummary<-getSampleSummary(laml)


## 生成突变分类矩阵
#使用 sig_tally() 对突变进行归类整理，针对 MAF 对象，支持设定 mode 为 ‘SBS’, ‘DBS’, ‘ID’ 以及 ‘ALL’

mats <- mt_tally <- sig_tally(
  laml,
  ref_genome = "BSgenome.Hsapiens.UCSC.hg38",
  useSyn = TRUE,
  mode = "ALL"
)
str(mats, max.level = 1)

# 针对整个数据集的分类就可以画图，Signatures 其实就是它的拆分。
show_catalogue(mt_tally$SBS_96 %>% t(), mode = "SBS", style = "cosmic")
show_catalogue(mt_tally$SBS_6 %>% t(), mode = "SBS", style = "cosmic")

## ------------ 估计 Signature 数目 --------------------
# 这一步实际上是多次运行 NMF，查看一些指标的变化，用于后续确定提取多少个 Signatures
# 运行最好30-50次可以得到稳定结果
est <- sig_estimate(mt_tally$SBS_96, range = 2:8, nrun = 50, verbose = TRUE)

show_sig_number_survey2(est$survey)
show_sig_number_survey(est$survey)
## --------------- 提取 signatures 和可视化 ----------------
sigs <- sig_extract(mt_tally$SBS_96, n_sig = 4, nrun = 200)
# 生成的是一个带 Signature 类信息的列表：
str(sigs, max.level = 1)
## 很多信息存在里面，可以自己提取自己感兴趣的信息
p <- show_sig_profile(sigs, mode = "SBS", style = "cosmic")
p

## 计算下它与 COSMIC signatures 的相似性，评估病因，对于 SBS 有 2 个 COSMIC 数据库
## 版本 legacy（30 个，目前最常用的） 与 SBS v3
get_sig_similarity(sigs, sig_db = "legacy")
sim <- get_sig_similarity(sigs, sig_db = "SBS")
add_labels(p, x = 0.72, y = 0.15, y_end = 0.9, labels = sim, n_label = 4)


## 自动提取 signatures
## SignatureAnalyzer 提供的变异 NMF 提供了自动提取 Sigantures 的功能，无需要自己判断提取的 signature 数目，这个可以通过 sig_auto_extract() 实现
sigs2 <- sig_auto_extract(mt_tally$SBS_96, nrun = 200)

## 绘图展示
p <- show_sig_profile(sigs2, mode = "SBS", style = "cosmic")
p

sim_legacy <-get_sig_similarity(sigs2, sig_db = "legacy")
sim <- get_sig_similarity(sigs2, sig_db = "SBS")
add_labels(p, x = 0.72, y = 0.15, y_end = 0.9, labels = sim_legacy, n_label = 3)

## ————————————————————  Signature 活动图谱  ——————————————————————————
# sigminer 提供绝对和相对两种 Signature 活动度值。
signature_matrix = get_sig_exposure(sigs2)
signature_matrix_relative = get_sig_exposure(sigs2, type = "relative")
show_sig_exposure(sigs, rm_space = TRUE, style = "cosmic")

write.csv(signature_matrix, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/Mutation_signatures/Mutation_signature_matrix.csv")
write.csv(signature_matrix_relative, "/Volumes/Samsung_T5/东方肝胆外科合作项目/data/WES/Results/Mutation_signatures/Mutation_signature_matrix_relative.csv")
## -------------- 根据已知的 Signatures 提取活动度 --------------------
examp_fit <- sig_fit(mt_tally$SBS_96[1:5, ] %>% t(), sig_index = "ALL", sig_db = "legacy")
head(examp_fit)

## 图形绘制
show_sig_fit(examp_fit, palette = NULL) + ggpubr::rotate_x_text()

## 设置散点图，绘制单样本结果
show_sig_fit(examp_fit,
             palette = NULL, plot_fun = "scatter",
             signatures = paste0("COSMIC_", c(1, 3, 5, 6, 12))
) + ggpubr::rotate_x_text()



