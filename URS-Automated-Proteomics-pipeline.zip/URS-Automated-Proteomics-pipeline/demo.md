```mermaid 
graph TD
    A[Config Page] -->|1. 用户填写参数| B[Submit 按钮]
    B --> C{前端验证}
    C -->|验证失败| D[显示错误提示]
    C -->|验证通过| E[调用 /api/config 保存参数]
    E --> F[生成 Unique_Run_ID]
    F --> G[自动跳转至 Workflow & Run Page]
    G --> H[加载 Sample Table]
    H --> I[显示 Start Pipeline 按钮]
    I -->|用户点击| J[调用 /api/run 启动流程]
    J --> K[实时显示日志流]
    
    style A fill:#4CAF50,stroke:#388E3C
    style G fill:#2196F3,stroke:#0D47A1
    style J fill:#FF9800,stroke:#F57C00
```






```mermaid 
graph TD
    A[Config Page] --> B[用户填写参数/选择默认值]
    A --> C[自动触发任务]
    B --> D[参数校验模块]
    C --> |加载预设参数|D
    D -->|校验失败| E[显示错误提示]
    D -->|校验成功| F[点击 Submit 按钮]
    F --> G[保存参数到内存/临时变量]
    F --> H[写入数据库/配置文件]
    F --> I[生成 Unique_Run_ID]
    H --> J[切换至 Workflow & Run 页面]
    I --> J
    J --> K[加载 Sample Table]
    J --> L[显示 Start Pipeline 按钮]
    K --> M[用户点击 Run 按钮]
    L --> M
    M --> N[执行Pipeline后端逻辑]

    %% === 改进的横向连接部分 ===
    N --> O[显示实时日志流]
    O --> |Render| Q[任务监测页面]
    N -.-> R[生成参数文件]
    N -.-> S[生成日志文件]
    
    style A fill:#4CAF50,stroke:#388E3C
    style D fill:#FFF8E1,stroke:#FFD54F
    style F fill:#C8E6C9,stroke#4CAF50
    style J fill:#2196F3,stroke:#0D47A1
    style M fill#FFCCBC,stroke#FF5722
    style N fill:#FF9800,stroke:#F57C00
    style Q fill:#FF9800,stroke:#F57C00

    classDef error fill:#FFEBEE,stroke:#F44336
    class E error

```

```mermaid
sequenceDiagram
    participant Frontend
    participant Backend
    participant Pipeline
    
    Frontend->>Backend: POST /api/run {run_id}
    Backend->>Pipeline: 启动处理进程
    loop 日志推送
        Pipeline->>Backend: 实时日志流
        Backend->>Frontend: SSE 事件流
    end
```

```mermaid
graph TB
    %% ===== 主功能区域 =====
    MP[Mission Monitor Page] --> F1[实时日志显示区]
    MP --> F2[运行状态指示器]
    MP --> F3[关键指标摘要]
    MP --> F4[暂停/继续控制]
    MP --> F5[错误警报系统]
    
    %% ===== 日志显示区子功能 =====
    F1 --> C1[时间排序的日志条目]
    F1 --> C2[级别着色]
    F1 --> C3[自动滚动最新]
    C2 -->|INFO| C2a[蓝色]
    C2 -->|WARN| C2b[黄色]
    C2 -->|ERROR| C2c[红色]
    
    %% ===== 关键指标摘要子功能 =====
    F3 --> D1[已处理样本数]
    F3 --> D2[进度百分比]
    F3 --> D3[预计剩余时间]
    
    %% ===== 错误警报子系统 =====
    F5 --> E1[实时错误高亮]
    F5 --> E2[通知告警]
    F5 --> E3[解决方案建议]
    E2 --> E2a[邮件通知]
    E2 --> E2b[SMS告警]
    
    %% ===== 样式定义 =====
    style MP fill:#D7CCC8,stroke:#5D4037
    style F1 fill:#E1F5FE,stroke:#039BE5
    style F2 fill:#FFF8E1,stroke:#FFD54F
    style F3 fill:#C8E6C9,stroke:#4CAF50
    style F4 fill:#FFCCBC,stroke:#FF5722
    style F5 fill:#FFEBEE,stroke:#F44336
    
    classDef info fill:#E3F2FD,stroke:#64B5F6
    class C2a info
    
    classDef warn fill:#FFF8E1,stroke:#FFD54F
    class C2b warn
    
    classDef error fill:#FFEBEE,stroke:#F44336
    class C2c,E1,E2,E3 error

```

```mermaid
sequenceDiagram
    participant Pipeline
    participant Monitor
    participant User
    
    Pipeline->>Monitor: 发送ERROR日志
    Monitor->>Monitor: 高亮显示错误行
    Monitor->>Monitor: 触发警报规则
    Monitor->>User: 发送邮件/SMS通知
    User->>Monitor: 查看解决方案建议
    User->>Pipeline: 执行修复操作

```