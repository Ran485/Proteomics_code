#!/bin/bash

# 指定工作目录（替换成你的路径）
WORKDIR="/Users/ranpeng/Library/Mobile Documents/com~apple~CloudDocs/BeiGene/URS-Automated-pipeline/Demo/1_Deposited_Dataset/Internal/Clinical"

# 获取当前目录basename
BASENAME=$(basename "$WORKDIR")

# 切换到工作目录
cd "$WORKDIR" || exit 1

# 创建3-4个文件夹
for i in {1..3}; do   # 改成 {1..4} 就是4个
    DIRNAME="${BASENAME}_Project${i}"
    mkdir -p "$DIRNAME"

    # 在每个目录里创建10个RAW文件
    for j in $(seq -w 1 10); do
        FILENAME=$(printf "Exp%07d_Bioinfo_BRCA_01_OE480_30cm_150min_2ug_20250810_F1_R1.raw" "$j")
        touch "$DIRNAME/$FILENAME"
    done
done

# 创建 Project_ID_sample_tracker.csv
echo "ProjectID,SampleName,Date" > Project_ID_sample_tracker.csv
echo "P001,Sample1,2025-08-13" >> Project_ID_sample_tracker.csv
